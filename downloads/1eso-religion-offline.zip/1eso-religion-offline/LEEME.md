# 1º ESO Religión Católica — pack offline

No hay que instalar nada. Descomprime y abre **ABRE-AQUI.html** (o index.html).

**Qué es:** pack confesional de **Religión Católica** de 1º ESO (BOE-A-2022-10452, Anexo ESO; marco de Castilla y León, Decreto 39/2022). **No es Alternativa laica.**
Este pack trae el **curso completo** (lecciones **01–30/30**) (Religión Católica 1º ESO: saberes básicos A–C del currículo confesional (BOE-A-2022-10452, Anexo ESO) y marco de Castilla y León (Decreto 39/2022); no es Alternativa laica) en HTML plano (shell + modo maestro).
Revisor Dios **CONFIRMA** OK curso (0 críticos).

**Cómo abrir (Android / PC) — 4 pasos**

1. Descarga el ZIP.
2. Abre **Archivos / Mis archivos** (NO la lista Descargas del navegador).
3. Descomprime y entra en la carpeta `1eso-religion-offline`.
4. Toca **`ABRE-AQUI.html`** o **`index.html`** → Chrome / Samsung Internet.

Todo funciona **offline**, sin nube ni servidor (`file://`). Sin instalación, sin app store, sin «setup».

**Importante en Android:** abre siempre desde la **carpeta descomprimida** (`file://`).
**Nunca** abras el HTML desde la lista Descargas del navegador (`content://`): ahí fallan
imágenes, CSS e interactivos.

En Chrome/Android: menú → **Añadir a pantalla de inicio**.

**Identidad:** material educativo confesional de **Religión Católica**. Se basa en BOE-A-2022-10452 y Decreto 39/2022. **No es Alternativa laica.** No sustituye al criterio del centro ni del profesorado.

**Contenido:** `ABRE-AQUI.html`, `index.html`, `LEEME.md`, `leccion-01`…`leccion-30-….html`,
alias `leccion-NN.html`, `maestro-NN.json`, carpeta `_maestro/`, calculadora, CSS/JS e iconos — todo en la misma carpeta.
