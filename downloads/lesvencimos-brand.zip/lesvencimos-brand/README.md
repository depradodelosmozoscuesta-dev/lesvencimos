# Les vencimos — pack de sistema visual

Landing oscura estática. No subir al repo: montar a mano.

## Nombres canónicos

| Archivo | Uso |
|---|---|
| `logo/logo-oscuro.svg` | Lockup sobre fondo oscuro (landing) |
| `logo/logo-claro.svg` | Lockup sobre fondo claro (print / merch) |
| `logo/logo-icono.svg` | Símbolo solo. ADN: rombo-gota + nervio + U + lluvia |
| `logo/logo-wordmark.svg` | Wordmark Source Sans 3 ExtraBold, tracking −0.04em |
| `logo/logo-wordmark-editorial.svg` | Wordmark Fraunces. Solo merch / print |
| `logo/logo-stacked-oscuro.svg` | Icono arriba + wordmark. Portada |
| `favicon/favicon.svg` | Favicon vector |
| `favicon/app-icon-512.png` | App icon / apple-touch 512 |
| `favicon/app-icon-1024.png` | App icon 1024 |
| `hero/hero.png` | Hero editorial 1920×1080 |
| `hero/hero-1600x900.png` | Hero 1600×900 |
| `hero/hero-1920x1080.png` | Variante geométrica (red = constelación) |
| `icons/icono-casa.svg` | Casa / asistente offline |
| `icons/icono-pucela.svg` | Pucela / merch Valladolid (soportales) |
| `icons/icono-red.svg` | Red ciudadana / WiFi paralelo |
| `patterns/lluvia-tile.svg` | Patrón tileable |
| `tokens.css` | Custom properties |
| `GUIA.md` | Márgenes, radios, do / don’t |
| `CHECKLIST.md` | Aplicación en HTML |
| `guia/tablero-sistema.png` | Tablero único del sistema |

## Convención de color en nombres

- `*-oscuro` = pensado para fondo oscuro (marca clara).
- `*-claro` = pensado para fondo claro (marca oscura).
