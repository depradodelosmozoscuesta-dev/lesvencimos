# Les vencimos — guía de sistema visual

Media página. Lo que no está aquí no es marca.

## Márgenes y ritmo

Escala base 8: 8 / 16 / 24 / 40 / 64 / 96.
Landing centrada. Bloque de claim máximo 36rem.
Padding de página: 40px laterales en desktop, 20px en móvil.
Header: logo-oscuro.svg a 36–44px de alto. No más.

## Radios

- Botón: 12px (ya en producción, no cambiar)
- Card / panel: 16px
- Pill de estado: 999px
- App icon: 22% del lado (rx 14 en viewBox 64)

## Tipo

Títulos de landing: system-ui / Source Sans 3 ExtraBold, peso 800, tracking −0.04em.
Cuerpo: system-ui, 400–650, color --suave. Strong en --tinta.
Sin Google Fonts. Sin Inter. Sin Satoshi.
Wordmark editorial (Fraunces 72pt Bold) solo merch / print. No en la landing HTML.

## Do

- Fondo #0B1220. Hero a cover, texto encima con overlay navy si hace falta.
- CTA primario = --acento con texto --tinta-oscura.
- Iconos de sección a 32px, stroke currentColor, no rellenar de acento salvo hover.
- Patrón lluvia a opacity 0.18–0.28, solo hero o footer. Nunca sobre texto.
- Español en toda la interfaz. Claim en --suave, “offline” en --tinta.
- Favicon.svg + apple-touch 180/512. theme-color #0B1220.

## Don’t

- No neon, no glitch, no degradados iridiscentes, no glassmorphism de startup.
- No logos de Big Tech, no cerebros, no copilot, no “AI-powered”.
- No texto blanco sobre --acento / --ok / --ambar / --peligro.
- No usar --lluvia como color de texto o de icono.
- No mezclar la paleta de Casa (ámbar #FBBF24, radio 16–18) en la landing.
- No sustituir el paraguas por uno genérico de stick + 8 varillas.
- No poner caras realistas en el hero.

## Lectura del símbolo

El rombo-gota es la lluvia condensada. El nervio y la U son el cobijo.
Que llueva la red; tú estás debajo.
