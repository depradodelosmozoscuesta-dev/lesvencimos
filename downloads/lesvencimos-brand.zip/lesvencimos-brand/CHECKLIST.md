# Checklist — aplicar el sistema en la landing HTML oscura

1. Tokens
   - Copiar `:root` de `tokens.css` al `<style>` de index.html (ya coinciden con producción).
   - `theme-color` = `#0B1220`.
   - No cargar Google Fonts. system-ui / Segoe UI. Fraunces solo si se self-hostea.

2. Favicon
   - Sustituir el data-URI actual por `favicon/favicon.svg`.
   - Añadir `<link rel="apple-touch-icon" href="favicon/app-icon-512.png">`.
   - Manifest / PWA: 512 y 1024.

3. Logo
   - Header / hero: `logo/logo-claro.svg` (paraguas + wordmark).
   - Fondo claro (merch, print): `logo/logo-oscuro.svg`.
   - Favicon / app: solo icono, nunca wordmark.

4. Hero
   - `hero/hero.png` (1920×1080) o `hero-1600x900.png`.
   - CSS: `object-fit: cover; max-height: 70vh;` sobre `--fondo`.
   - No superponer texto encima de la tablet ámbar.

5. Iconos de sección
   - Casa → `icons/icono-casa.svg`
   - Pucela → `icons/icono-pucela.svg`
   - Red ciudadana → `icons/icono-red.svg`
   - `width:32px; color: var(--acento);` (usan currentColor).

6. Patrón lluvia
   - `pattern/patron-lluvia.svg` como `background-image` tile.
   - Opacidad 0.35–0.5 sobre `--fondo`. Nunca detrás de texto pequeño.

7. Componentes
   - Botón primario: `--acento` + texto `--tinta-oscura`, radius 12px.
   - Ghost: borde `--linea`, texto `--tinta`.
   - Pill “Asistente en camino”: dot `--ok`.
   - Cards: `--fondo-2`, borde `--linea`, radius 16px.

8. Copy
   - Claim intacto. Español. Sin hype de IA.
   - CTAs actuales: Descargar Casa / Abrir Casa / Pucela / Red / Juego.

9. Contraste
   - No texto claro sobre acento/ok/ámbar.
   - `--suave` solo sobre `--fondo` o `--fondo-2`.

10. Offline
    - Assets en `/brand/` o inline SVG. Nada de CDN.
