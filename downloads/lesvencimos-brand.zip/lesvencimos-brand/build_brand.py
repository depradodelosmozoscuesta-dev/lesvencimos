#!/usr/bin/env python3
"""Les vencimos — sistema visual. Genera SVG + PNG de producción."""

from __future__ import annotations

import math
import os
from pathlib import Path

from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.misc.transform import Transform
from PIL import Image, ImageDraw

ROOT = Path("/home/workdir/artifacts/lesvencimos-brand")
FONT_WORD = Path(
    "/usr/share/fonts/SlidesCarnival/google/Source Sans 3/static/SourceSans3-ExtraBold.ttf"
)
FONT_WORD_SOFT = Path(
    "/usr/share/fonts/SlidesCarnival/google/Fraunces/static/Fraunces_72pt-Bold.ttf"
)

# ---------------------------------------------------------------------------
# Paleta
# ---------------------------------------------------------------------------
BG = "#0B1220"
SURFACE = "#121A2B"
SURFACE2 = "#182236"
TEXT = "#E8EEF8"
MUTED = "#8B9BB8"
ACCENT = "#C7D2FE"
ACCENT2 = "#A5B4FC"
RAIN = "#4A5A78"
AMBER = "#E8B86D"
OK = "#34D399"
DANGER = "#F87171"
BORDER = "#1E2A40"
INK = "#0B1220"
SLATE = "#64748B"


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print(f"  wrote {path.relative_to(ROOT)} ({path.stat().st_size} bytes)")


# ---------------------------------------------------------------------------
# Wordmark → SVG paths
# ---------------------------------------------------------------------------
def text_to_paths(
    text: str,
    font_path: Path,
    size: float,
    tracking_em: float = -0.04,
) -> tuple[str, float, float]:
    """Return (path d concatenated as several <path>), width, height (em box)."""
    font = TTFont(str(font_path))
    glyph_set = font.getGlyphSet()
    cmap = font.getBestCmap()
    upem = font["head"].unitsPerEm
    scale = size / upem
    hmtx = font["hmtx"]
    asc = font["hhea"].ascent * scale
    desc = abs(font["hhea"].descent) * scale
    tracking = tracking_em * size

    parts: list[str] = []
    x = 0.0
    chars = list(text)
    for i, ch in enumerate(chars):
        gname = cmap.get(ord(ch), ".notdef")
        pen = SVGPathPen(glyph_set)
        tpen = TransformPen(pen, Transform(scale, 0, 0, -scale, x, asc))
        glyph_set[gname].draw(tpen)
        d = pen.getCommands()
        if d:
            parts.append(d)
        adv = hmtx[gname][0] * scale
        x += adv
        if i < len(chars) - 1:
            x += tracking
    width = x
    height = asc + desc
    return " ".join(parts), width, height


def svg_wrap(inner: str, w: float, h: float, vb_pad: float = 0) -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="'
        f'{-vb_pad:.2f} {-vb_pad:.2f} {w + 2 * vb_pad:.2f} {h + 2 * vb_pad:.2f}" '
        f'fill="none" role="img">\n{inner}\n</svg>\n'
    )


# ---------------------------------------------------------------------------
# Marca: paraguas (ADN de producción, geometría limpia)
# viewBox 0 0 96 96
# ---------------------------------------------------------------------------
def umbrella_mark(
    fill: str,
    stroke: str,
    rain: str | None = None,
    with_rain: bool = True,
    sw: float = 4.0,
) -> str:
    """Paraguas Les vencimos: rombo-gota + nervio + copa + lluvia."""
    rain_color = rain or SLATE
    parts = []
    if with_rain:
        parts.append(
            f'  <path stroke="{rain_color}" stroke-width="2.4" stroke-linecap="round" '
            f'opacity="0.72" d="M30 16v7.5M48 12v9.5M66 16v7.5M38.5 20v5.5M57.5 20v5.5"/>'
        )
    # rombo-gota (semilla / gota vista de frente) — distintivo de la marca
    parts.append(
        f'  <path fill="{fill}" d="M48 10c-1.15 9.6-9.6 14.4-16.8 16.8C38.2 29.2 46.7 34 48 43.6'
        f'c1.15-9.6 9.6-14.4 16.8-16.8C57.8 24.4 49.3 19.6 48 10z"/>'
    )
    parts.append(
        f'  <path stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" '
        f'd="M18 49.5h60"/>'
    )
    parts.append(
        f'  <path stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" '
        f'd="M26 49.5c0 15.5 8 27.5 22 32.5 14-5 22-17 22-32.5"/>'
    )
    return "\n".join(parts)


def umbrella_simple(fill: str, stroke: str, sw: float = 3.2, bowl_fill: str | None = None) -> str:
    """Favicon: sin lluvia, geometría más gruesa. bowl_fill evita hueco negro al rasterizar."""
    parts = []
    if bowl_fill:
        parts.append(
            f'  <path fill="{bowl_fill}" d="M18 33.5C18 43.7 23.2 51.7 32 55C40.8 51.7 46 43.7 46 33.5Z"/>'
        )
    parts.extend(
        [
            f'  <path fill="{fill}" d="M32 6.5c-.7 6.4-6.2 9.6-11.2 11.2C25.6 19.3 31.2 22.5 32 29'
            f'c.7-6.5 6.2-9.7 11.2-11.3C38.4 16.1 32.8 12.9 32 6.5z"/>',
            f'  <path stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" fill="none" d="M12 33.5h40"/>',
            f'  <path stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" fill="none" '
            f'd="M18 33.5c0 10.2 5.2 18.2 14 21.5 8.8-3.3 14-11.3 14-21.5"/>',
        ]
    )
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Iconos de sección — trazo 2.25, viewBox 48, cap/join round
# ---------------------------------------------------------------------------
STROKE_ICON = 2.25


def icon_casa(color: str) -> str:
    # Casa con tejado a dos aguas + ventana ámbar (asistente offline)
    return f"""  <g fill="none" stroke="{color}" stroke-width="{STROKE_ICON}" stroke-linecap="round" stroke-linejoin="round">
    <path d="M8 22.5 L24 10 L40 22.5"/>
    <path d="M11.5 21.5 V38.5 H36.5 V21.5"/>
    <rect x="20" y="26" width="8" height="7.5" rx="1.2"/>
  </g>
  <rect x="21.2" y="27.2" width="5.6" height="5.1" rx="0.7" fill="{AMBER}" opacity="0.9"/>"""


def icon_pucela(color: str) -> str:
    # Tres arcos de soportal — Plaza Mayor, ciudad, no escudo de club
    return f"""  <g fill="none" stroke="{color}" stroke-width="{STROKE_ICON}" stroke-linecap="round" stroke-linejoin="round">
    <path d="M6 38.5 V22.5"/>
    <path d="M18 38.5 V22.5"/>
    <path d="M30 38.5 V22.5"/>
    <path d="M42 38.5 V22.5"/>
    <path d="M6 22.5 C6 14.5 10.5 11 12 11 C13.5 11 18 14.5 18 22.5"/>
    <path d="M18 22.5 C18 14.5 22.5 11 24 11 C25.5 11 30 14.5 30 22.5"/>
    <path d="M30 22.5 C30 14.5 34.5 11 36 11 C37.5 11 42 14.5 42 22.5"/>
    <path d="M6 10.2 H42"/>
    <path d="M6 38.5 H42"/>
  </g>"""


def icon_red(color: str) -> str:
    # Malla de 3 nodos + arco de cobertura (WiFi paralelo / barrio)
    return f"""  <g fill="none" stroke="{color}" stroke-width="{STROKE_ICON}" stroke-linecap="round" stroke-linejoin="round">
    <path d="M24 16 L12.5 33.5"/>
    <path d="M24 16 L35.5 33.5"/>
    <path d="M12.5 33.5 H35.5"/>
    <path d="M16 11.5 C19.2 8.8 21.6 7.5 24 7.5 C26.4 7.5 28.8 8.8 32 11.5" opacity="0.95"/>
    <path d="M19.2 14.2 C20.8 12.8 22.4 12.2 24 12.2 C25.6 12.2 27.2 12.8 28.8 14.2" opacity="0.7"/>
  </g>
  <circle cx="24" cy="16" r="2.35" fill="{color}"/>
  <circle cx="12.5" cy="33.5" r="2.35" fill="{color}"/>
  <circle cx="35.5" cy="33.5" r="2.35" fill="{color}"/>"""


def icon_svg(name: str, inner: str, color: str = "currentColor") -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" fill="none" '
        f'role="img" aria-label="{name}">\n{inner}\n</svg>\n'
    )


# ---------------------------------------------------------------------------
# Patrón lluvia tileable
# ---------------------------------------------------------------------------
def rain_pattern_svg(size: int = 128) -> str:
    drops = []
    # grid irregular, determinista
    coords = [
        (10, 4, 18),
        (22, 28, 14),
        (34, 8, 20),
        (46, 36, 16),
        (58, 12, 22),
        (70, 40, 12),
        (82, 6, 18),
        (94, 30, 20),
        (106, 16, 14),
        (118, 42, 16),
        (16, 52, 16),
        (40, 60, 18),
        (64, 70, 14),
        (88, 56, 20),
        (112, 68, 12),
        (28, 86, 18),
        (52, 92, 14),
        (76, 84, 20),
        (100, 96, 16),
        (8, 100, 14),
    ]
    for x, y, length in coords:
        op = 0.22 + ((x * 13 + y * 7) % 17) / 80.0
        drops.append(
            f'    <line x1="{x}" y1="{y}" x2="{x}" y2="{y + length}" '
            f'stroke="{RAIN}" stroke-width="1.15" stroke-linecap="round" opacity="{op:.2f}"/>'
        )
    inner = "\n".join(drops)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {size}" width="{size}" height="{size}">
  <defs>
    <pattern id="lluvia" x="0" y="0" width="{size}" height="{size}" patternUnits="userSpaceOnUse">
{inner}
    </pattern>
  </defs>
  <rect width="100%" height="100%" fill="url(#lluvia)"/>
</svg>
'''


def rain_tile_png(path: Path, size: int = 256) -> None:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    coords = [
        (20, 8, 36),
        (44, 56, 28),
        (68, 16, 40),
        (92, 72, 32),
        (116, 24, 44),
        (140, 80, 24),
        (164, 12, 36),
        (188, 60, 40),
        (212, 32, 28),
        (236, 84, 32),
        (32, 104, 32),
        (80, 120, 36),
        (128, 140, 28),
        (176, 112, 40),
        (224, 136, 24),
        (56, 172, 36),
        (104, 184, 28),
        (152, 168, 40),
        (200, 192, 32),
        (16, 200, 28),
        (72, 220, 24),
        (160, 228, 30),
        (248, 210, 26),
    ]
    rain_rgb = (74, 90, 120)
    for x, y, length in coords:
        op = 40 + ((x * 13 + y * 7) % 50)
        d.line((x, y, x, y + length), fill=(*rain_rgb, op), width=2)
    img.save(path)
    print(f"  wrote {path.relative_to(ROOT)}")


# ---------------------------------------------------------------------------
# Raster helpers via ImageMagick
# ---------------------------------------------------------------------------
def raster(svg_path: Path, png_path: Path, width: int, background: str | None = None) -> None:
    png_path.parent.mkdir(parents=True, exist_ok=True)
    bg = background if background else "none"
    cmd = (
        f'convert -background "{bg}" -density 384 "{svg_path}" '
        f'-resize {width}x "{png_path}"'
    )
    rc = os.system(cmd + " >/dev/null 2>&1")
    if rc != 0:
        print(f"  WARN convert failed {svg_path.name} -> {png_path.name}")
    else:
        print(f"  raster {png_path.relative_to(ROOT)} w={width}")


def main() -> None:
    print("== Les vencimos brand build ==")

    # --- icono solo ---
    icon_dark = (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" fill="none" '
        'role="img" aria-label="Les vencimos">\n'
        + umbrella_mark(TEXT, MUTED, SLATE, True)
        + "\n</svg>\n"
    )
    icon_light = (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" fill="none" '
        'role="img" aria-label="Les vencimos">\n'
        + umbrella_mark(INK, BORDER, RAIN, True)
        + "\n</svg>\n"
    )
    write(ROOT / "logo" / "logo-icono.svg", icon_dark)
    write(ROOT / "logo" / "logo-icono-claro.svg", icon_light)

    # --- wordmark paths ---
    d_word, ww, wh = text_to_paths("Les vencimos", FONT_WORD, 72, tracking_em=-0.045)
    word_dark = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {ww:.2f} {wh:.2f}" '
        f'role="img" aria-label="Les vencimos">\n'
        f'  <path fill="{TEXT}" d="{d_word}"/>\n</svg>\n'
    )
    word_light = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {ww:.2f} {wh:.2f}" '
        f'role="img" aria-label="Les vencimos">\n'
        f'  <path fill="{INK}" d="{d_word}"/>\n</svg>\n'
    )
    write(ROOT / "logo" / "logo-wordmark.svg", word_dark)
    write(ROOT / "logo" / "logo-wordmark-claro.svg", word_light)

    # editorial wordmark (Fraunces) — variante print
    d_soft, sw, sh = text_to_paths("Les vencimos", FONT_WORD_SOFT, 72, tracking_em=-0.02)
    write(
        ROOT / "logo" / "logo-wordmark-editorial.svg",
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {sw:.2f} {sh:.2f}" '
        f'role="img" aria-label="Les vencimos">\n'
        f'  <path fill="{TEXT}" d="{d_soft}"/>\n</svg>\n',
    )

    # --- lockup horizontal: icono + wordmark ---
    # icon 96 → scale so icon height ≈ wordmark cap height
    icon_target_h = 78
    scale = icon_target_h / 96
    icon_w = 96 * scale
    gap = 18
    lock_w = icon_w + gap + ww
    lock_h = max(icon_target_h, wh)
    icon_y = (lock_h - icon_target_h) / 2
    text_y = (lock_h - wh) / 2

    def lockup(fill_icon: str, stroke_icon: str, rain_c: str, fill_text: str) -> str:
        mark = umbrella_mark(fill_icon, stroke_icon, rain_c, True, sw=4.0)
        return (
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {lock_w:.2f} {lock_h:.2f}" '
            f'role="img" aria-label="Les vencimos">\n'
            f'  <g transform="translate(0 {icon_y:.2f}) scale({scale:.4f})">\n{mark}\n  </g>\n'
            f'  <g transform="translate({icon_w + gap:.2f} {text_y:.2f})">\n'
            f'    <path fill="{fill_text}" d="{d_word}"/>\n  </g>\n</svg>\n'
        )

    write(ROOT / "logo" / "logo-oscuro.svg", lockup(TEXT, MUTED, SLATE, TEXT))
    write(ROOT / "logo" / "logo-claro.svg", lockup(INK, BORDER, RAIN, INK))

    # lockup stacked (icono arriba, wordmark abajo) — hero / portada
    stack_gap = 16
    stack_w = max(96, ww)
    stack_h = 96 + stack_gap + wh
    icon_x = (stack_w - 96) / 2
    text_x = (stack_w - ww) / 2
    # "Les vencimos" no tiene descendentes: recortamos el em-box inferior
    word_tight_h = wh * 0.78
    stack_gap = 10
    stack_w = max(96, ww)
    stack_h = 96 + stack_gap + word_tight_h
    icon_x = (stack_w - 96) / 2
    text_x = (stack_w - ww) / 2
    write(
        ROOT / "logo" / "logo-stacked-oscuro.svg",
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {stack_w:.2f} {stack_h:.2f}" '
        f'role="img" aria-label="Les vencimos">\n'
        f'  <g transform="translate({icon_x:.2f} 0)">\n'
        + umbrella_mark(TEXT, MUTED, SLATE, True)
        + f"\n  </g>\n"
        f'  <g transform="translate({text_x:.2f} {96 + stack_gap:.2f})">\n'
        f'    <path fill="{TEXT}" d="{d_word}"/>\n  </g>\n</svg>\n',
    )
    write(
        ROOT / "logo" / "logo-stacked-claro.svg",
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {stack_w:.2f} {stack_h:.2f}" '
        f'role="img" aria-label="Les vencimos">\n'
        f'  <g transform="translate({icon_x:.2f} 0)">\n'
        + umbrella_mark(INK, BORDER, RAIN, True)
        + f"\n  </g>\n"
        f'  <g transform="translate({text_x:.2f} {96 + stack_gap:.2f})">\n'
        f'    <path fill="{INK}" d="{d_word}"/>\n  </g>\n</svg>\n',
    )

    # --- favicon ---
    fav = (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">\n'
        + umbrella_simple(TEXT, MUTED, sw=3.4)
        + "\n</svg>\n"
    )
    write(ROOT / "favicon" / "favicon.svg", fav)

    # app icon con fondo (no transparente) 512 / 1024
    def app_icon_svg(size_label: str) -> str:
        return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="{size_label}" height="{size_label}">
  <rect width="64" height="64" rx="14" fill="{BG}"/>
  <rect x="0.6" y="0.6" width="62.8" height="62.8" rx="13.4" fill="none" stroke="{BORDER}" stroke-width="1.2"/>
{umbrella_simple(TEXT, MUTED, sw=3.2, bowl_fill=BG)}
</svg>
'''

    write(ROOT / "favicon" / "app-icon.svg", app_icon_svg("512"))

    # --- iconos sección ---
    write(ROOT / "icons" / "icon-casa.svg", icon_svg("Casa / asistente offline", icon_casa("currentColor")))
    write(ROOT / "icons" / "icon-pucela.svg", icon_svg("Pucela / merch Valladolid", icon_pucela("currentColor")))
    write(ROOT / "icons" / "icon-red.svg", icon_svg("Red ciudadana / WiFi paralelo", icon_red("currentColor")))
    # versiones tintadas para preview
    write(ROOT / "icons" / "icon-casa-tinta.svg", icon_svg("Casa", icon_casa(ACCENT)))
    write(ROOT / "icons" / "icon-pucela-tinta.svg", icon_svg("Pucela", icon_pucela(ACCENT)))
    write(ROOT / "icons" / "icon-red-tinta.svg", icon_svg("Red ciudadana", icon_red(ACCENT)))

    # --- patrón ---
    write(ROOT / "patterns" / "lluvia-tile.svg", rain_pattern_svg(128))
    rain_tile_png(ROOT / "patterns" / "lluvia-tile.png", 256)

    # --- raster logos ---
    raster(ROOT / "logo" / "logo-oscuro.svg", ROOT / "logo" / "logo-oscuro.png", 1200, "none")
    raster(ROOT / "logo" / "logo-claro.svg", ROOT / "logo" / "logo-claro.png", 1200, "none")
    raster(ROOT / "logo" / "logo-icono.svg", ROOT / "logo" / "logo-icono.png", 512, "none")
    raster(ROOT / "logo" / "logo-icono-claro.svg", ROOT / "logo" / "logo-icono-claro.png", 512, "none")
    raster(ROOT / "logo" / "logo-wordmark.svg", ROOT / "logo" / "logo-wordmark.png", 1200, "none")
    raster(ROOT / "logo" / "logo-stacked-oscuro.svg", ROOT / "logo" / "logo-stacked-oscuro.png", 900, "none")
    raster(ROOT / "icons" / "icon-casa-tinta.svg", ROOT / "icons" / "icon-casa.png", 256, "none")
    raster(ROOT / "icons" / "icon-pucela-tinta.svg", ROOT / "icons" / "icon-pucela.png", 256, "none")
    raster(ROOT / "icons" / "icon-red-tinta.svg", ROOT / "icons" / "icon-red.png", 256, "none")

    # favicons raster on dark rounded square
    raster(ROOT / "favicon" / "app-icon.svg", ROOT / "favicon" / "favicon-512.png", 512, BG)
    raster(ROOT / "favicon" / "app-icon.svg", ROOT / "favicon" / "favicon-1024.png", 1024, BG)
    raster(ROOT / "favicon" / "app-icon.svg", ROOT / "favicon" / "apple-touch-icon.png", 180, BG)
    raster(ROOT / "favicon" / "favicon.svg", ROOT / "favicon" / "favicon-32.png", 32, "none")

    print("done.")


if __name__ == "__main__":
    main()
