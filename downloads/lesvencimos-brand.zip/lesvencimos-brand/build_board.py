#!/usr/bin/env python3
"""Tablero único del sistema visual Les vencimos."""

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path("/home/workdir/artifacts/lesvencimos-brand")
OUT = ROOT / "guia" / "tablero-sistema.png"

BG = (11, 18, 32, 255)
SURFACE = (18, 26, 43, 255)
TEXT = (232, 238, 248, 255)
MUTED = (139, 155, 184, 255)
LINE = (30, 42, 64, 255)

SWATCHES = [
    ("fondo", "#0B1220", (11, 18, 32)),
    ("surface", "#121A2B", (18, 26, 43)),
    ("tinta", "#E8EEF8", (232, 238, 248)),
    ("suave", "#8B9BB8", (139, 155, 184)),
    ("acento", "#C7D2FE", (199, 210, 254)),
    ("ámbar", "#E8B86D", (232, 184, 109)),
    ("ok", "#34D399", (52, 211, 153)),
    ("peligro", "#F87171", (248, 113, 113)),
    ("lluvia", "#4A5A78", (74, 90, 120)),
]

FONT_SANS = "/usr/share/fonts/SlidesCarnival/google/Source Sans 3/static/SourceSans3-Regular.ttf"
FONT_BOLD = "/usr/share/fonts/SlidesCarnival/google/Source Sans 3/static/SourceSans3-Bold.ttf"
FONT_XB = "/usr/share/fonts/SlidesCarnival/google/Source Sans 3/static/SourceSans3-ExtraBold.ttf"


def font(path, size):
    return ImageFont.truetype(path, size)


def paste_rgba(base, src, xy, max_w=None, max_h=None):
    im = src.convert("RGBA")
    if max_w or max_h:
        im.thumbnail((max_w or im.width, max_h or im.height), Image.Resampling.LANCZOS)
    base.alpha_composite(im, dest=xy)
    return im.size


def main():
    W, H = 1920, 1280
    canvas = Image.new("RGBA", (W, H), BG)
    d = ImageDraw.Draw(canvas)

    title = font(FONT_XB, 44)
    label = font(FONT_BOLD, 15)
    small = font(FONT_SANS, 14)
    tiny = font(FONT_SANS, 12)

    d.text((64, 48), "Les vencimos", font=title, fill=TEXT)
    d.text((64, 108), "Sistema visual  ·  soberanía digital offline", font=small, fill=MUTED)

    # paleta
    d.text((64, 168), "PALETA", font=label, fill=MUTED)
    x0, y0 = 64, 198
    sw, sh, gap = 168, 88, 12
    for i, (name, hexv, rgb) in enumerate(SWATCHES):
        x = x0 + (i % 5) * (sw + gap)
        y = y0 + (i // 5) * (sh + 36)
        d.rounded_rectangle([x, y, x + sw, y + sh], radius=10, fill=rgb + (255,))
        if name in ("fondo", "surface", "lluvia"):
            d.rounded_rectangle([x, y, x + sw, y + sh], radius=10, outline=LINE, width=1)
        tc = (11, 18, 32, 255) if name in ("tinta", "acento", "ámbar", "ok") else TEXT
        d.text((x + 12, y + sh + 6), f"{name}  {hexv}", font=tiny, fill=MUTED)

    # logos
    d.text((64, 470), "MARCA", font=label, fill=MUTED)
    card = Image.new("RGBA", (1792, 220), SURFACE)
    canvas.alpha_composite(card, (64, 500))
    logo = Image.open(ROOT / "logo" / "logo-oscuro.png")
    paste_rgba(canvas, logo, (96, 548), max_w=720, max_h=120)

    stacked = Image.open(ROOT / "logo" / "logo-stacked-oscuro.png")
    paste_rgba(canvas, stacked, (880, 520), max_w=280, max_h=180)

    fav = Image.open(ROOT / "favicon" / "favicon-512.png")
    paste_rgba(canvas, fav, (1240, 536), max_w=148, max_h=148)

    icono = Image.open(ROOT / "logo" / "logo-icono.png")
    paste_rgba(canvas, icono, (1440, 536), max_w=148, max_h=148)

    d.text((1240, 692), "app icon 512", font=tiny, fill=MUTED)
    d.text((1440, 692), "icono solo", font=tiny, fill=MUTED)

    # iconos seccion
    d.text((64, 748), "SECCIÓN", font=label, fill=MUTED)
    names = [("icono-casa.png", "Casa"), ("icono-pucela.png", "Pucela"), ("icono-red.png", "Red ciudadana")]
    for i, (fn, nm) in enumerate(names):
        x = 64 + i * 280
        card_i = Image.new("RGBA", (248, 168), SURFACE)
        canvas.alpha_composite(card_i, (x, 778))
        ic = Image.open(ROOT / "icons" / fn)
        paste_rgba(canvas, ic, (x + 68, 798), max_w=112, max_h=112)
        d.text((x + 24, 910), nm, font=tiny, fill=MUTED)

    # patron
    d.text((920, 748), "PATRÓN LLUVIA", font=label, fill=MUTED)
    rain = Image.open(ROOT / "patterns" / "lluvia-tile.png").convert("RGBA")
    tile = Image.new("RGBA", (248, 168), BG)
    for yy in range(0, 168, 128):
        for xx in range(0, 248, 128):
            tile.alpha_composite(rain.resize((128, 128)), (xx, yy))
    # fade
    tile_card = Image.new("RGBA", (248, 168), SURFACE)
    tile_card.alpha_composite(tile)
    canvas.alpha_composite(tile_card, (920, 778))

    # hero thumb
    d.text((1210, 748), "HERO 1920×1080", font=label, fill=MUTED)
    hero = Image.open(ROOT / "hero" / "hero.png").convert("RGBA")
    hero.thumbnail((646, 168), Image.Resampling.LANCZOS)
    # clip rounded
    mask = Image.new("L", hero.size, 0)
    md = ImageDraw.Draw(mask)
    md.rounded_rectangle([0, 0, hero.size[0] - 1, hero.size[1] - 1], radius=10, fill=255)
    hero.putalpha(mask)
    canvas.alpha_composite(hero, (1210, 778))

    d.text((64, 1198), "Que llueva la red — tú estás a salvo.", font=small, fill=MUTED)
    d.text((1480, 1198), "lesvencimos.com", font=small, fill=MUTED)

    canvas.convert("RGB").save(OUT, "PNG", optimize=True)
    print("board", OUT, canvas.size)


if __name__ == "__main__":
    main()
