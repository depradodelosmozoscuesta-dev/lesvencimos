# 1º ESO Educación Plástica, Visual y Audiovisual — pack offline

No hay que instalar nada. Descomprime y abre **ABRE-AQUI.html** (o index.html).

**Qué es:** lecciones de **Educación obligatoria** (currículo oficial Castilla y León, Decreto 39/2022 · EPVA).
Este pack trae el **curso completo** (lecciones **01–31/31**) (temario completo EPVA 1º CyL (patrimonio, lenguaje visual, geometría, técnicas, medios)) en HTML plano (shell + práctica Tinta embebida donde hay widget).
Revisor Dios **CONFIRMA** OK curso (0 críticos).

**Cómo abrir (Android / PC) — 4 pasos**

1. Descarga el ZIP.
2. Abre **Archivos / Mis archivos** (NO la lista Descargas del navegador).
3. Descomprime y entra en la carpeta `1eso-plastica-visual-offline`.
4. Toca **`ABRE-AQUI.html`** o **`index.html`** → Chrome / Samsung Internet.

Todo funciona **offline**, sin nube ni servidor (`file://`). Sin instalación, sin app store, sin «setup».

**Importante en Android:** abre siempre desde la **carpeta descomprimida** (`file://`).
**Nunca** abras el HTML desde la lista Descargas del navegador (`content://`): ahí fallan
imágenes, CSS e interactivos.

En Chrome/Android: menú → **Añadir a pantalla de inicio**.

La práctica **Tinta Estudio** va **embebida** en las lecciones con widget (y también suelta como `tinta-estudio.html`).
Si hace falta, cada lección con práctica tiene «Abrir a pantalla completa →».

**Contenido:** `ABRE-AQUI.html`, `index.html`, `LEEME.md`, `leccion-01`…`leccion-31-….html`,
alias `leccion-NN.html`, widgets Tinta, `tinta-estudio.html`, calculadora, CSS/JS e iconos — todo en la misma carpeta.
