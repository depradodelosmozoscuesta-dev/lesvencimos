import json
from http.server import BaseHTTPRequestHandler, HTTPServer
class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_POST(self):
        body=json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        open("/tmp/ia_pet.json","w").write(json.dumps(body,ensure_ascii=False))
        self.send_response(200); self.send_header("Content-Type","text/event-stream"); self.end_headers()
        for w in ["Una ", "fracción ", "es ", "una parte."]:
            self.wfile.write(("data: "+json.dumps({"choices":[{"delta":{"content":w}}]})+"\n\n").encode()); self.wfile.flush()
        self.wfile.write(b"data: [DONE]\n\n")
HTTPServer(("127.0.0.1",8082),H).serve_forever()
