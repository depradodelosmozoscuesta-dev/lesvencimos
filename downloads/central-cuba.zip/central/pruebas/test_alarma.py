"""Pruebas del decodificador y del registro de la alarma. Uso: python3 pruebas/test_alarma.py"""
import os
import sqlite3
import subprocess
import sys
import tempfile

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, "alarma"))
import trama  # noqa: E402
import escucha_alarma as ea  # noqa: E402

fallos = 0
pruebas = 0


def ok(c, msg):
    global fallos, pruebas
    pruebas += 1
    if not c:
        fallos += 1
        print("FALLO:", msg)


# 1) Mismos bytes que el Arduino (compila Bus485.h real si está al lado)
bus_h = os.environ.get("BUS485_H")
if bus_h and os.path.exists(bus_h):
    src = r'''#include <cstdio>
#include "Bus485.h"
int main(){ uint8_t b[7]; for(int t=1;t<=2;t++) for(int id=1;id<=8;id++) for(int e=0;e<5;e++) for(int c=0;c<6;c++){
 bus::Trama x={(uint8_t)t,(uint8_t)id,(uint8_t)e,(uint8_t)c,(uint8_t)(id*37+e*5+c)}; bus::codificar(x,b);
 for(int i=0;i<7;i++) printf("%02x",b[i]); printf("\n");} }'''
    with tempfile.TemporaryDirectory() as d:
        open(os.path.join(d, "g.cpp"), "w").write(src)
        subprocess.run(["g++", "-std=c++11", "-I", os.path.dirname(bus_h), os.path.join(d, "g.cpp"), "-o", os.path.join(d, "g")], check=True)
        salida = subprocess.run([os.path.join(d, "g")], capture_output=True, text=True, check=True).stdout.split()
    i = 0
    iguales = True
    for t in (1, 2):
        for casa in range(1, 9):
            for e in range(5):
                for c in range(6):
                    if trama.codificar(t, casa, e, c, casa * 37 + e * 5 + c).hex() != salida[i]:
                        iguales = False
                    i += 1
    ok(iguales and i == 480, "Python y Arduino generan las mismas 480 tramas")
else:
    print("(aviso) BUS485_H no indicado: no comparo con el código del Arduino")

# 2) Lector: basura, trama corrupta, trama pegada
L = trama.Lector()
buena = trama.codificar(trama.T_ALARMA, 3, 4, 1, 9)
mala = bytearray(trama.codificar(trama.T_LATIDO, 2, 2, 0, 1)); mala[3] ^= 1
r = L.meter_bloque(b"\x00\x13\xa5\x01" + bytes(mala) + buena + buena)
ok(len(r) >= 1 and r[-1]["casa"] == 3 and r[-1]["tipo"] == trama.T_ALARMA, "recupera tras basura y trama corrupta")
ok(L.errores >= 1, "cuenta errores")
ok(trama.Lector().meter_bloque(trama.codificar(1, 9, 0, 0, 0)) == [], "rechaza casa 9")

# 3) Registro con reloj simulado
reloj = [1000.0]
with tempfile.TemporaryDirectory() as d:
    con = ea.abrir_db(os.path.join(d, "a.db"))
    reg = ea.Registro(con, reloj=lambda: reloj[0])

    def ev():
        return [r[0] for r in con.execute("SELECT texto FROM eventos ORDER BY id")]

    reg.trama({"tipo": 1, "casa": 2, "estado": 0, "causa": 0, "seq": 1})
    ok(ev() == ["Casa 2 conectada a la red"], "primera vez: conectada")
    reloj[0] += 5; reg.trama({"tipo": 1, "casa": 2, "estado": 0, "causa": 0, "seq": 2})
    ok(len(ev()) == 1, "latido igual no apunta nada")
    reloj[0] += 5; reg.trama({"tipo": 1, "casa": 2, "estado": 1, "causa": 0, "seq": 3})
    ok(ev()[-1] == "Casa 2: armando", "cambio de estado")
    for k in range(20):  # alarma: una trama por segundo durante 20 s
        reloj[0] += 1; reg.trama({"tipo": 2, "casa": 2, "estado": 4, "causa": 3, "seq": 10 + k})
    alarmas = [e for e in ev() if e.startswith("ALARMA")]
    ok(alarmas == ["ALARMA en casa 2 (ventana)"], "alarma apuntada una vez con su causa")
    reloj[0] += 61; reg.trama({"tipo": 2, "casa": 2, "estado": 4, "causa": 3, "seq": 40})
    ok(len([e for e in ev() if e.startswith("ALARMA")]) == 2, "vuelve a apuntar si sigue tras 60 s")
    reloj[0] += 31; reg.revisar()
    ok(ev()[-1].startswith("Casa 2 no se oye"), "detecta casa sin señal a los 30 s")
    reg.revisar()
    ok(sum(e.startswith("Casa 2 no se oye") for e in ev()) == 1, "sin señal se apunta una vez")
    reloj[0] += 1; reg.trama({"tipo": 1, "casa": 2, "estado": 0, "causa": 0, "seq": 41})
    ok("Casa 2 vuelve a oírse" in ev(), "vuelve a oírse")
    fila = con.execute("SELECT estado, sin_senal FROM casas WHERE casa=2").fetchone()
    ok(fila == (0, 0), "tabla casas al día")

print(f"{pruebas} pruebas, {fallos} fallos")
sys.exit(1 if fallos else 0)
