#!/bin/bash
cd /tmp
socat -d pty,raw,echo=0,link=/tmp/ttyV0,mode=666 pty,raw,echo=0,link=/tmp/ttyV1,mode=666 >/dev/null 2>&1 &
sleep 1
rm -f /srv/central/alarma.db*
su -s /bin/sh central -c "CENTRAL_PUERTO=/tmp/ttyV1 CENTRAL_DB=/srv/central/alarma.db nohup python3 /opt/central/alarma/escucha_alarma.py > /tmp/esc.log 2>&1 &"
su -s /bin/sh central -c "CENTRAL_DATOS=/srv/central nohup python3 /opt/central/portal/portal.py > /tmp/portal.log 2>&1 &"
nohup python3 /tmp/fake_ia.py >/dev/null 2>&1 &
sleep 1.5
python3 /tmp/enviar.py; sleep 1.5
echo "--- api/alarma"; curl -s localhost:8000/api/alarma | python3 -c "import json,sys; d=json.load(sys.stdin); print([ (c['casa'],c['estado'],c['causa']) for c in d['casas']]); [print(' ',e['nivel'],e['texto']) for e in d['eventos']]"
cat /tmp/esc.log /tmp/portal.log
