import sys,time; sys.path.insert(0,"/opt/central/alarma"); import trama, serial
p=serial.Serial("/tmp/ttyV0",9600)
for s in range(3):
    for casa in (1,2,3): p.write(trama.codificar(1,casa,2,0,s)); time.sleep(0.05)
    time.sleep(0.3)
p.write(b"\x00\xff\xa5garbage")
for s in range(3): p.write(trama.codificar(2,3,4,5,50+s)); time.sleep(0.3)
p.close()
