#!/usr/bin/env bash
# Instalador de la Central de casa (Orange Pi 5, Ubuntu/Debian arm64)
#
# Uso:  sudo ./instalar.sh todo              # todo lo que se pueda, con internet (en España)
#       sudo ./instalar.sh base portal alarma # fases sueltas
#       sudo ./instalar.sh profesor /ruta/profesor.html
#       sudo ./instalar.sh estado             # qué hay instalado
#
# Fases: base portal alarma biblioteca ia khan estudiante escritorio
# Se puede repetir sin miedo: cada fase comprueba lo que ya existe.
set -euo pipefail

AQUI="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=central.conf
[ -f "$AQUI/central.conf" ] && . "$AQUI/central.conf"
# shellcheck source=/dev/null
[ -f /etc/central.conf ] && . /etc/central.conf

DATOS="${DATOS:-/srv/central}"
CODIGO="${CODIGO:-/opt/central}"
PUERTO_SERIE="${PUERTO_SERIE:-/dev/ttyUSB0}"
ZIMS="${ZIMS:-wikipedia_es_all_nopic vikidia_es_all_maxi|vikidia_es_all wikibooks_es_all_maxi|wikibooks_es_all_nopic wiktionary_es_all_maxi|wiktionary_es_all_nopic phet_es_all_maxi|phet_es_all|phet_es}"
MODELO_URL="${MODELO_URL:-https://huggingface.co/Qwen/Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q4_K_M.gguf}"
KIWIX_BASE="${KIWIX_BASE:-https://download.kiwix.org/zim}"
HILOS_IA="${HILOS_IA:-4}"
USUARIO_SERVICIO=central

verde() { printf '\033[1;32m%s\033[0m\n' "$*"; }
amarillo() { printf '\033[1;33m%s\033[0m\n' "$*"; }
rojo() { printf '\033[1;31m%s\033[0m\n' "$*" >&2; }
paso() { printf '\n\033[1;36m== %s ==\033[0m\n' "$*"; }

hay_systemd() { [ -d /run/systemd/system ]; }

requiere_root() {
  if [ "$(id -u)" -ne 0 ]; then rojo "Ejecuta con sudo: sudo $0 $*"; exit 1; fi
}

requiere_internet() {
  if ! curl -fsS -m 10 -o /dev/null https://download.kiwix.org/ 2>/dev/null &&
     ! curl -fsS -m 10 -o /dev/null https://huggingface.co/ 2>/dev/null; then
    rojo "Esta fase necesita internet. Hazla en España, antes del viaje."
    return 1
  fi
}

apt_instalar() {
  export DEBIAN_FRONTEND=noninteractive
  local faltan=()
  for p in "$@"; do dpkg -s "$p" >/dev/null 2>&1 || faltan+=("$p"); done
  [ ${#faltan[@]} -eq 0 ] && return 0
  apt-get update -q
  apt-get install -y -q "${faltan[@]}"
}

# Escribe un servicio systemd. $1 nombre, $2 descripción, $3 ExecStart, resto: líneas extra de [Service]
servicio() {
  local nombre="$1" desc="$2" exec="$3"; shift 3
  local f="/etc/systemd/system/${nombre}.service"
  {
    echo "[Unit]"
    echo "Description=$desc"
    echo "After=network.target"
    echo
    echo "[Service]"
    echo "User=$USUARIO_SERVICIO"
    echo "ExecStart=$exec"
    echo "Restart=always"
    echo "RestartSec=5"
    for l in "$@"; do echo "$l"; done
    echo
    echo "[Install]"
    echo "WantedBy=multi-user.target"
  } > "$f"
  if hay_systemd; then
    systemctl daemon-reload
    systemctl enable --now "$nombre" >/dev/null
    systemctl restart "$nombre"
    verde "Servicio $nombre en marcha"
  else
    amarillo "Sin systemd aquí: escrito $f pero no arrancado"
  fi
}

# ---------------- FASES ----------------
fase_base() {
  paso "Base: paquetes, usuario del sistema y carpetas"
  apt_instalar python3 python3-serial python3-markdown sqlite3 curl git rsync ufw \
    nano vim-tiny htop tree man-db less bash-completion \
    iproute2 iputils-ping traceroute dnsutils net-tools nmap tcpdump whois \
    build-essential cmake python3-venv
  id "$USUARIO_SERVICIO" >/dev/null 2>&1 || useradd --system --home "$DATOS" --shell /usr/sbin/nologin "$USUARIO_SERVICIO"
  usermod -aG dialout "$USUARIO_SERVICIO"
  mkdir -p "$DATOS"/{profesor,cursos,biblioteca,modelos,khan} "$CODIGO"
  rsync -a --delete --exclude pruebas/ --exclude llama.cpp/ --exclude kolibri-venv/ --exclude biblioteca.sh --exclude ia.sh "$AQUI"/ "$CODIGO"/
  # Los cursos incluidos se copian sin borrar los que se hayan añadido después
  rsync -a "$AQUI/cursos/" "$DATOS/cursos/"
  [ -f /etc/central.conf ] || cp "$AQUI/central.conf" /etc/central.conf
  chown -R "$USUARIO_SERVICIO": "$DATOS"
  chmod 755 "$DATOS"
  # Cortafuegos: nada entra desde fuera; todo lo de la central escucha solo en 127.0.0.1
  if command -v ufw >/dev/null && hay_systemd; then
    ufw default deny incoming >/dev/null
    ufw default allow outgoing >/dev/null
    ufw --force enable >/dev/null
    verde "Cortafuegos activo (entrada cerrada)"
  fi
  verde "Base lista. Código en $CODIGO, datos en $DATOS"
}

fase_portal() {
  paso "Portal (página de inicio en http://localhost:8000)"
  servicio central-portal "Central de casa - portal" "/usr/bin/python3 $CODIGO/portal/portal.py" \
    "Environment=CENTRAL_DATOS=$DATOS" "Environment=CENTRAL_PUERTO_WEB=8000" \
    "Environment=CENTRAL_IA=http://127.0.0.1:8082"
}

fase_alarma() {
  paso "Escucha de la alarma vecinal (adaptador USB-RS485 en $PUERTO_SERIE)"
  servicio central-alarma "Central de casa - escucha de la alarma" "/usr/bin/python3 $CODIGO/alarma/escucha_alarma.py" \
    "Environment=CENTRAL_PUERTO=$PUERTO_SERIE" "Environment=CENTRAL_DB=$DATOS/alarma.db" \
    "Environment=PYTHONUNBUFFERED=1"
}

ultimo_zim() {  # $1 prefijo, p. ej. wikipedia_es_all_nopic -> nombre del ZIM más reciente
  local pref="$1" dir="${1%%_*}"
  curl -fsSL -m 60 "$KIWIX_BASE/$dir/" | grep -o "${pref}_[0-9]\{4\}-[0-9]\{2\}\.zim" | sort -u | sort -V | tail -1
}

# $1 = alternativas separadas por | ; devuelve "prefijo zim" de la primera que exista
elegir_zim() {
  local alt z alts
  IFS='|' read -r -a alts <<< "$1"
  for alt in "${alts[@]}"; do
    z="$(ultimo_zim "$alt" || true)"
    if [ -n "$z" ]; then echo "$alt $z"; return 0; fi
  done
  return 1
}

fase_biblioteca() {
  paso "Biblioteca offline (Kiwix)"
  requiere_internet
  if ! apt_instalar kiwix-tools; then
    rojo "No encuentro kiwix-tools en los repositorios. Instálalo a mano desde https://kiwix.org"
    return 1
  fi
  local d="$DATOS/biblioteca"
  local entrada elegido pref zim url
  for entrada in $ZIMS; do
    if ! elegido="$(elegir_zim "$entrada")"; then amarillo "No encuentro $entrada en $KIWIX_BASE (se salta)"; continue; fi
    pref="${elegido%% *}"; zim="${elegido#* }"
    url="$KIWIX_BASE/${pref%%_*}/$zim"
    if [ -f "$d/$zim" ]; then verde "Ya está: $zim"; continue; fi
    echo "Descargando $zim (se puede cortar y volver a lanzar: continúa donde iba)"
    curl -fL -C - --retry 5 -o "$d/$zim.part" "$url"
    if curl -fsSL -m 60 "$url.sha256" -o "$d/$zim.sha256" 2>/dev/null; then
      ( cd "$d" && sed "s#[^ ]*\$#$zim.part#" "$zim.sha256" | sha256sum -c --quiet ) \
        || { rojo "La suma de control de $zim no coincide: bórralo y repite"; rm -f "$d/$zim.sha256"; return 1; }
      rm -f "$d/$zim.sha256"
    fi
    mv "$d/$zim.part" "$d/$zim"
    # Quita versiones viejas del mismo ZIM
    find "$d" -maxdepth 1 -name "${pref}_*.zim" ! -name "$zim" -delete
    verde "Descargado $zim"
  done
  chown -R "$USUARIO_SERVICIO": "$d"
  cat > "$CODIGO/biblioteca.sh" <<EOF
#!/bin/sh
# Sirve todos los ZIM de la carpeta; si se añade uno, basta con reiniciar el servicio
exec kiwix-serve --address=127.0.0.1 --port=8081 $d/*.zim
EOF
  chmod 755 "$CODIGO/biblioteca.sh"
  servicio central-biblioteca "Central de casa - biblioteca Kiwix" "$CODIGO/biblioteca.sh"
}

fase_ia() {
  paso "IA local (llama.cpp + Qwen3 4B, licencia Apache 2.0)"
  requiere_internet
  apt_instalar build-essential cmake git curl
  local src="$CODIGO/llama.cpp"
  if [ ! -d "$src/.git" ]; then git clone --depth 1 https://github.com/ggml-org/llama.cpp.git "$src"; fi
  if [ ! -x "$src/build/bin/llama-server" ]; then
    echo "Compilando llama.cpp (en la Orange Pi 5 tarda unos 15-20 minutos)…"
    cmake -S "$src" -B "$src/build" -DCMAKE_BUILD_TYPE=Release -DGGML_NATIVE=ON -DLLAMA_CURL=OFF
    cmake --build "$src/build" --target llama-server -j "$(nproc)"
  fi
  local modelo
  modelo="$DATOS/modelos/$(basename "$MODELO_URL")"
  if [ ! -f "$modelo" ]; then
    curl -fL -C - --retry 5 -o "$modelo.part" "$MODELO_URL"
    mv "$modelo.part" "$modelo"
  fi
  chown -R "$USUARIO_SERVICIO": "$DATOS/modelos"
  cat > "$CODIGO/ia.sh" <<EOF
#!/bin/sh
# enable_thinking=false: Qwen3 contesta directamente, sin «pensar» en voz alta (más rápido)
exec "$src/build/bin/llama-server" -m "$modelo" --host 127.0.0.1 --port 8082 \\
  -c 4096 -t $HILOS_IA -np 1 --chat-template-kwargs '{"enable_thinking":false}'
EOF
  chmod 755 "$CODIGO/ia.sh"
  servicio central-ia "Central de casa - IA local" "$CODIGO/ia.sh"
}

fase_khan() {
  paso "Khan Academy en español (Kolibri)"
  requiere_internet
  apt_instalar python3-venv
  local venv="$CODIGO/kolibri-venv"
  [ -x "$venv/bin/kolibri" ] || { python3 -m venv "$venv" && "$venv/bin/pip" install -q --upgrade pip kolibri; }
  mkdir -p "$DATOS/khan" && chown -R "$USUARIO_SERVICIO": "$DATOS/khan"
  servicio central-khan "Central de casa - Kolibri (Khan Academy)" "$venv/bin/kolibri start --foreground --port 8083" \
    "Environment=KOLIBRI_HOME=$DATOS/khan"
  amarillo "Ahora, CON INTERNET: abre http://localhost:8083, completa el asistente y en"
  amarillo "Dispositivo → Canales → Importar elige «Khan Academy (Español)» y los niveles que quieras."
}

fase_estudiante() {
  paso "Cuenta «estudiante» (sin permisos de administrador)"
  if id estudiante >/dev/null 2>&1; then verde "Ya existe"; return 0; fi
  useradd --create-home --shell /bin/bash --comment "Estudiante" estudiante
  if [ -t 0 ]; then echo "Contraseña para «estudiante»:"; passwd estudiante
  else amarillo "Pon su contraseña luego con: sudo passwd estudiante"; fi
}

fase_escritorio() {
  paso "Abrir el portal al iniciar sesión"
  mkdir -p /etc/xdg/autostart
  cat > /etc/xdg/autostart/central-portal.desktop <<'EOF'
[Desktop Entry]
Type=Application
Name=Central de casa
Comment=Abre la página de inicio de la central
Exec=sh -c "sleep 8; xdg-open http://localhost:8000"
X-GNOME-Autostart-enabled=true
EOF
  cat > /usr/share/applications/central-portal.desktop <<'EOF'
[Desktop Entry]
Type=Application
Name=Central de casa
Comment=Profesor, cursos, biblioteca y alarma
Exec=xdg-open http://localhost:8000
Icon=user-home
Categories=Education;
EOF
  verde "Listo: el navegador abrirá la central en cada inicio de sesión"
}

fase_profesor() {
  local html="${1:-}"
  paso "Profesor"
  if [ -z "$html" ] || [ ! -f "$html" ]; then rojo "Uso: sudo $0 profesor /ruta/al/profesor.html"; return 1; fi
  mkdir -p "$DATOS/profesor"
  install -m 644 "$html" "$DATOS/profesor/index.html"
  chown -R "$USUARIO_SERVICIO": "$DATOS/profesor"
  verde "Profesor instalado: http://localhost:8000/profesor/"
}

fase_estado() {
  paso "Estado"
  for s in portal alarma biblioteca ia khan; do
    if hay_systemd && systemctl is-active --quiet "central-$s"; then verde "central-$s: en marcha"
    elif [ -f "/etc/systemd/system/central-$s.service" ]; then amarillo "central-$s: instalado, parado"
    else echo "central-$s: no instalado"; fi
  done
  [ -f "$DATOS/profesor/index.html" ] && verde "profesor: instalado" || echo "profesor: falta"
  echo "Espacio en $DATOS:"; df -h "$DATOS" | tail -1
  ls -1 "$DATOS/biblioteca"/*.zim 2>/dev/null || echo "Sin ZIM en la biblioteca"
}

# ---------------- MAIN ----------------
[ $# -eq 0 ] && { sed -n '2,12p' "$0"; exit 0; }
case "$1" in estado) fase_estado; exit 0 ;; esac
requiere_root "$@"

if [ "$1" = profesor ]; then fase_profesor "${2:-}"; exit $?; fi
[ "$1" = todo ] && set -- base portal alarma escritorio estudiante biblioteca ia khan

fallos=()
for f in "$@"; do
  case "$f" in
    base|portal|alarma|biblioteca|ia|khan|estudiante|escritorio)
      # Cada fase en un subshell con set -e: si algo falla, esa fase se para y se sigue con la siguiente
      set +e; ( set -e; "fase_$f" ); rc=$?; set -e
      [ $rc -eq 0 ] || fallos+=("$f") ;;
    *) rojo "Fase desconocida: $f"; fallos+=("$f") ;;
  esac
done

if [ ${#fallos[@]} -eq 0 ]; then verde $'\nTodo correcto. Abre http://localhost:8000'
else rojo $'\nFallaron: '"${fallos[*]}"' (el resto está hecho; puedes repetir solo esas)'; exit 1; fi
