#!/usr/bin/env python3
"""Escucha el cable de la alarma vecinal (RS-485) y guarda lo que pasa en SQLite.

Solo escucha: nunca transmite, así que no puede estropear el bus.
Configuración por variables de entorno (las pone el servicio systemd):
    CENTRAL_PUERTO   /dev/ttyUSB0
    CENTRAL_DB       /srv/central/alarma.db
"""
import os
import sqlite3
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import trama  # noqa: E402

PUERTO = os.environ.get("CENTRAL_PUERTO", "/dev/ttyUSB0")
DB = os.environ.get("CENTRAL_DB", "/srv/central/alarma.db")
SIN_SENAL_S = 30        # igual que en el Arduino
REPETIR_ALARMA_S = 60   # no apuntar la misma alarma más de una vez por minuto


def abrir_db(ruta):
    con = sqlite3.connect(ruta, timeout=10)
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript("""
        CREATE TABLE IF NOT EXISTS casas(
            casa INTEGER PRIMARY KEY, visto REAL, estado INTEGER, causa INTEGER,
            sin_senal INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS eventos(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, casa INTEGER,
            nivel TEXT, texto TEXT);
    """)
    con.commit()
    return con


class Registro:
    def __init__(self, con, reloj=time.time):
        self.con = con
        self.reloj = reloj
        self.ultima_alarma = {}

    def evento(self, casa, nivel, texto):
        self.con.execute("INSERT INTO eventos(ts, casa, nivel, texto) VALUES(?,?,?,?)",
                         (self.reloj(), casa, nivel, texto))

    def trama(self, t):
        ahora = self.reloj()
        casa = t["casa"]
        fila = self.con.execute("SELECT estado, sin_senal FROM casas WHERE casa=?", (casa,)).fetchone()
        if fila is None:
            self.evento(casa, "info", f"Casa {casa} conectada a la red")
        else:
            estado_prev, sin_senal = fila
            if sin_senal:
                self.evento(casa, "info", f"Casa {casa} vuelve a oírse")
            if estado_prev != t["estado"] and t["estado"] != 4:
                self.evento(casa, "info", f"Casa {casa}: {trama.ESTADOS.get(t['estado'], '?')}")
        if t["tipo"] == trama.T_ALARMA:
            if ahora - self.ultima_alarma.get(casa, -1e9) >= REPETIR_ALARMA_S:
                causa = trama.CAUSAS.get(t["causa"], "")
                self.evento(casa, "alarma", f"ALARMA en casa {casa}" + (f" ({causa})" if causa else ""))
            self.ultima_alarma[casa] = ahora
        self.con.execute(
            "INSERT INTO casas(casa, visto, estado, causa, sin_senal) VALUES(?,?,?,?,0) "
            "ON CONFLICT(casa) DO UPDATE SET visto=excluded.visto, estado=excluded.estado, "
            "causa=excluded.causa, sin_senal=0",
            (casa, ahora, t["estado"], t["causa"]))
        self.con.commit()

    def revisar(self):
        ahora = self.reloj()
        filas = self.con.execute(
            "SELECT casa FROM casas WHERE sin_senal=0 AND visto < ?", (ahora - SIN_SENAL_S,)).fetchall()
        for (casa,) in filas:
            self.evento(casa, "aviso", f"Casa {casa} no se oye (cable cortado o sin batería)")
            self.con.execute("UPDATE casas SET sin_senal=1 WHERE casa=?", (casa,))
        if filas:
            self.con.commit()


def main():
    import serial  # python3-serial
    con = abrir_db(DB)
    reg = Registro(con)
    lector = trama.Lector()
    avisado = False
    while True:
        try:
            with serial.Serial(PUERTO, 9600, timeout=1) as p:
                print(f"Escuchando {PUERTO}", flush=True)
                if avisado:
                    reg.evento(0, "info", "Adaptador RS-485 conectado de nuevo")
                    con.commit()
                avisado = False
                ultima_rev = 0.0
                while True:
                    for t in lector.meter_bloque(p.read(64)):
                        reg.trama(t)
                    if time.time() - ultima_rev >= 5:
                        reg.revisar()
                        ultima_rev = time.time()
        except (serial.SerialException, OSError) as e:
            if not avisado:
                print(f"No puedo abrir {PUERTO}: {e}. Reintento cada 5 s.", flush=True)
                reg.evento(0, "aviso", f"No encuentro el adaptador RS-485 ({PUERTO})")
                con.commit()
                avisado = True
            time.sleep(5)


if __name__ == "__main__":
    main()
