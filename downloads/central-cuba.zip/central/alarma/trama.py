"""Decodificador de las tramas RS-485 de la alarma vecinal.

Debe coincidir byte a byte con Bus485.h del Arduino:
    A5 | tipo | id | estado | causa | secuencia | CRC-8 (poli 0x07, inicio 0)
"""

SYNC = 0xA5
LARGO = 7
MAX_CASAS = 8
T_LATIDO = 1
T_ALARMA = 2

ESTADOS = {0: "desarmada", 1: "armando", 2: "armada", 3: "alguien entrando", 4: "ALARMA"}
CAUSAS = {0: "", 1: "puerta", 2: "movimiento", 3: "ventana", 4: "sabotaje", 5: "botón de pánico"}


def crc8(datos):
    c = 0
    for b in datos:
        c ^= b
        for _ in range(8):
            c = ((c << 1) ^ 0x07) & 0xFF if c & 0x80 else (c << 1) & 0xFF
    return c


def codificar(tipo, casa, estado, causa, seq):
    cuerpo = bytes([SYNC, tipo, casa, estado, causa, seq & 0xFF])
    return cuerpo + bytes([crc8(cuerpo)])


class Lector:
    """Se le meten bytes sueltos; devuelve tramas válidas como diccionarios."""

    def __init__(self):
        self.buf = bytearray()
        self.errores = 0

    def meter(self, b):
        if not self.buf and b != SYNC:
            return None
        self.buf.append(b)
        if len(self.buf) < LARGO:
            return None
        trama = bytes(self.buf)
        self.buf.clear()
        if crc8(trama[:6]) != trama[6]:
            self.errores += 1
            # Buscar otro A5 dentro de lo recibido para no perder la trama siguiente
            i = trama.find(bytes([SYNC]), 1)
            if i > 0:
                self.buf.extend(trama[i:])
            return None
        tipo, casa, estado, causa, seq = trama[1:6]
        if tipo not in (T_LATIDO, T_ALARMA) or not 1 <= casa <= MAX_CASAS:
            return None
        return {"tipo": tipo, "casa": casa, "estado": estado, "causa": causa, "seq": seq}

    def meter_bloque(self, datos):
        salida = []
        for b in datos:
            t = self.meter(b)
            if t:
                salida.append(t)
        return salida
