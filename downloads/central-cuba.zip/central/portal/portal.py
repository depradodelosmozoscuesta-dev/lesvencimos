#!/usr/bin/env python3
"""Portal de la Central de casa: página de inicio offline en http://localhost:8000

Solo usa la biblioteca estándar de Python (y python3-markdown si está instalado).
Variables de entorno:
    CENTRAL_DATOS   /srv/central         (profesor/, cursos/, alarma.db)
    CENTRAL_PUERTO_WEB  8000
    CENTRAL_IA      http://127.0.0.1:8082 (llama-server)
"""
import html
import json
import mimetypes
import os
import re
import socket
import sqlite3
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

DATOS = os.environ.get("CENTRAL_DATOS", "/srv/central")
PUERTO_WEB = int(os.environ.get("CENTRAL_PUERTO_WEB", "8000"))
IA = os.environ.get("CENTRAL_IA", "http://127.0.0.1:8082")
PUERTOS = {"biblioteca": 8081, "ia": 8082, "khan": 8083}

try:
    import markdown as _md

    def md_a_html(texto):
        return _md.markdown(texto, extensions=["tables", "fenced_code", "sane_lists"])
except ImportError:  # sin python3-markdown: se muestra como texto
    def md_a_html(texto):
        return "<pre>" + html.escape(texto) + "</pre>"

SISTEMA_IA = (
    "Eres el profesor de la casa: un ordenador sin internet que ayuda a estudiar a niños mayores "
    "y adultos. Habla en español sencillo, cálido y preciso. Frases cortas. Si no sabes algo o no "
    "estás seguro, dilo y sugiere buscarlo en la Biblioteca. Cuando alguien haga un ejercicio, no "
    "des la solución de golpe: primero una pista, luego una solución parcial y solo después la "
    "solución completa. Nunca calcules dosis de medicamentos: di que eso lo decide un médico o "
    "farmacéutico. No des opiniones políticas; en historia explica los hechos y los distintos "
    "puntos de vista sin tomar partido. En informática y ciberseguridad enseña a proteger equipos "
    "y a practicar solo en ordenadores propios o de práctica, nunca en sistemas ajenos."
)

CSS = """
:root{--fondo:#F4F6F3;--papel:#FFFFFF;--tinta:#1B2620;--suave:#5B6A62;--linea:#D7DED9;
--acento:#1F6F5C;--acento-s:#DCEFE8;--rojo:#C3312A;--rojo-s:#F8E3E0;--ambar:#9A6A00;--ambar-s:#F6EDD3;
--f:"Segoe UI",Roboto,"Noto Sans",Ubuntu,Cantarell,sans-serif;--m:ui-monospace,"DejaVu Sans Mono",monospace}
@media (prefers-color-scheme:dark){:root{--fondo:#111714;--papel:#19211D;--tinta:#E5ECE7;--suave:#9DAAA2;
--linea:#2D3933;--acento:#5CC4A6;--acento-s:#1C3A31;--rojo:#FF6A5C;--rojo-s:#3A1D1A;--ambar:#E6B63E;--ambar-s:#352C14}}
*{box-sizing:border-box}
body{margin:0;background:var(--fondo);color:var(--tinta);font:18px/1.6 var(--f);padding-inline:16px;padding-block:0 60px}
a{color:var(--acento)}
.barra{max-width:960px;margin:0 auto;display:flex;flex-wrap:wrap;gap:6px 18px;align-items:center;padding-block:14px;border-bottom:2px solid var(--tinta)}
.barra .marca{font-weight:700;font-size:20px;margin-right:auto;text-decoration:none;color:var(--tinta)}
.barra a{text-decoration:none;font-weight:600}
main{max-width:960px;margin:0 auto;padding-top:28px;display:flex;flex-direction:column;gap:24px}
h1{font-size:34px;line-height:1.15;margin:0}
h2{font-size:24px;margin:0}
.sub{color:var(--suave);margin:0;max-width:62ch}
.rejilla{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,270px),1fr));gap:14px}
.tile{display:flex;flex-direction:column;gap:6px;background:var(--papel);border:1px solid var(--linea);border-radius:8px;padding:18px;text-decoration:none;color:var(--tinta);min-height:140px}
.tile:hover,.tile:focus-visible{border-color:var(--acento);outline:2px solid var(--acento);outline-offset:0}
.tile b{font-size:21px}
.tile span{color:var(--suave);font-size:16px}
.estado{margin-top:auto;font:600 13px var(--m);letter-spacing:.5px}
.on{color:var(--acento)} .off{color:var(--suave)}
.aviso{background:var(--rojo-s);border-left:5px solid var(--rojo);padding:14px 18px;border-radius:0 8px 8px 0;font-weight:600}
.nota{background:var(--ambar-s);border-left:5px solid var(--ambar);padding:12px 16px;border-radius:0 8px 8px 0;max-width:70ch}
.lista{display:flex;flex-direction:column;gap:0;background:var(--papel);border:1px solid var(--linea);border-radius:8px}
.lista a{display:flex;gap:12px;padding:14px 16px;border-bottom:1px solid var(--linea);text-decoration:none;color:var(--tinta)}
.lista a:last-child{border-bottom:0}
.lista .n{font:600 14px var(--m);color:var(--suave);min-width:2.5em}
.lista .ok{margin-left:auto;color:var(--acento);font-weight:700}
.leccion{background:var(--papel);border:1px solid var(--linea);border-radius:8px;padding:8px 24px 24px;max-width:780px}
.leccion pre{background:var(--fondo);padding:12px;border-radius:6px;overflow-x:auto;font:15px/1.5 var(--m)}
.leccion code{font-family:var(--m);font-size:.9em}
.leccion table{border-collapse:collapse;display:block;overflow-x:auto}
.leccion th,.leccion td{border:1px solid var(--linea);padding:6px 10px}
.nav{display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between;max-width:780px}
button,.boton{font:600 17px var(--f);padding:10px 18px;border-radius:6px;border:2px solid var(--acento);background:var(--acento);color:var(--papel);cursor:pointer;text-decoration:none}
button.sec,.boton.sec{background:transparent;color:var(--acento)}
.casas{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,200px),1fr));gap:12px}
.casa{background:var(--papel);border:2px solid var(--linea);border-radius:8px;padding:14px}
.casa.alarma{border-color:var(--rojo);background:var(--rojo-s)}
.casa.perdida{border-color:var(--ambar);background:var(--ambar-s)}
.casa b{font-size:20px;display:block}
.eventos{font-size:16px;background:var(--papel);border:1px solid var(--linea);border-radius:8px;overflow-x:auto}
.eventos table{border-collapse:collapse;width:100%}
.eventos td{padding:8px 12px;border-bottom:1px solid var(--linea);vertical-align:top}
.eventos td:first-child{font-family:var(--m);white-space:nowrap;color:var(--suave)}
.eventos tr.alarma td{color:var(--rojo);font-weight:700}
.chat{display:flex;flex-direction:column;gap:10px;max-width:780px}
.msg{padding:12px 16px;border-radius:8px;white-space:pre-wrap;max-width:90%}
.msg.yo{align-self:flex-end;background:var(--acento-s)}
.msg.ia{align-self:flex-start;background:var(--papel);border:1px solid var(--linea)}
form.preg{display:flex;gap:10px;max-width:780px;flex-wrap:wrap}
form.preg textarea{flex:1 1 300px;font:17px/1.5 var(--f);padding:10px;border-radius:6px;border:1px solid var(--linea);background:var(--papel);color:var(--tinta);min-height:70px}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
"""


def pagina(titulo, cuerpo, extra_js=""):
    return f"""<!doctype html><html lang="es"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(titulo)} · Central de casa</title><style>{CSS}</style></head><body>
<nav class="barra"><a class="marca" href="/">Central de casa</a>
<a href="/profesor/">Profesor</a><a href="/cursos">Cursos</a><a href="/biblioteca">Biblioteca</a>
<a href="/ia">Preguntar</a><a href="/alarma">Alarma</a></nav>
<main>{cuerpo}</main>{extra_js}</body></html>"""


def puerto_abierto(p):
    try:
        with socket.create_connection(("127.0.0.1", p), timeout=0.25):
            return True
    except OSError:
        return False


def dentro(base, ruta_rel):
    """Devuelve la ruta real si queda dentro de base; si no, None (evita ../../)."""
    base = os.path.realpath(base)
    destino = os.path.realpath(os.path.join(base, ruta_rel))
    if destino == base or destino.startswith(base + os.sep):
        return destino
    return None


# ---------------- Cursos ----------------
RE_LECCION = re.compile(r"^(\d+)[-_ ].*\.md$")


def cursos():
    base = os.path.join(DATOS, "cursos")
    salida = []
    if not os.path.isdir(base):
        return salida
    for nombre in sorted(os.listdir(base)):
        d = os.path.join(base, nombre)
        info_f = os.path.join(d, "curso.json")
        if not os.path.isfile(info_f):
            continue
        try:
            with open(info_f, encoding="utf-8") as f:
                info = json.load(f)
        except (OSError, ValueError):
            continue
        info["slug"] = nombre
        info["lecciones"] = lecciones(nombre)
        salida.append(info)
    return salida


def lecciones(curso):
    d = dentro(os.path.join(DATOS, "cursos"), curso)
    if not d or not os.path.isdir(d):
        return []
    lista = []
    for f in sorted(os.listdir(d), key=lambda x: (int(RE_LECCION.match(x).group(1)) if RE_LECCION.match(x) else 0, x)):
        if not RE_LECCION.match(f):
            continue
        titulo = f[:-3]
        try:
            with open(os.path.join(d, f), encoding="utf-8") as fh:
                for linea in fh:
                    if linea.startswith("# "):
                        titulo = linea[2:].strip()
                        break
        except OSError:
            continue
        lista.append({"archivo": f, "slug": f[:-3], "titulo": titulo})
    return lista


# ---------------- Alarma ----------------
def datos_alarma():
    ruta = os.path.join(DATOS, "alarma.db")
    res = {"casas": [], "eventos": [], "ahora": time.time(), "hay_db": os.path.exists(ruta)}
    if not res["hay_db"]:
        return res
    try:
        con = sqlite3.connect(f"file:{ruta}?mode=ro", uri=True, timeout=2)
        for casa, visto, estado, causa, sin in con.execute(
                "SELECT casa, visto, estado, causa, sin_senal FROM casas ORDER BY casa"):
            res["casas"].append({"casa": casa, "visto": visto, "estado": estado, "causa": causa, "sin_senal": sin})
        for ts, casa, nivel, texto in con.execute(
                "SELECT ts, casa, nivel, texto FROM eventos ORDER BY id DESC LIMIT 60"):
            res["eventos"].append({"ts": ts, "casa": casa, "nivel": nivel, "texto": texto})
        con.close()
    except sqlite3.Error as e:
        res["error"] = str(e)
    return res


def alarma_reciente(segundos=180):
    d = datos_alarma()
    for e in d["eventos"]:
        if e["nivel"] == "alarma" and d["ahora"] - e["ts"] < segundos:
            return e["texto"]
    return None


JS_ALARMA = r"""<script>
const EST={0:"Desarmada",1:"Armando",2:"Armada",3:"Alguien entrando",4:"ALARMA"};
const CAU={0:"",1:"puerta",2:"movimiento",3:"ventana",4:"sabotaje",5:"botón de pánico"};
function hora(ts){const d=new Date(ts*1000);return d.toLocaleDateString("es",{day:"2-digit",month:"2-digit"})+" "+d.toLocaleTimeString("es",{hour:"2-digit",minute:"2-digit",second:"2-digit"});}
function esc(s){const e=document.createElement("span");e.textContent=s;return e.innerHTML;}
async function pintar(){
  try{
    const r=await fetch("/api/alarma");const d=await r.json();
    const c=document.getElementById("casas");
    if(!d.casas.length){c.innerHTML='<p class="sub">Todavía no se ha oído ninguna casa por el cable. Comprueba que el adaptador RS-485 está enchufado.</p>';}
    else c.innerHTML=d.casas.map(k=>{
      const perdida=k.sin_senal||d.ahora-k.visto>30; const al=k.estado==4;
      const txt=perdida?"Sin señal":EST[k.estado]+(al&&CAU[k.causa]?" · "+CAU[k.causa]:"");
      return `<div class="casa ${al?"alarma":perdida?"perdida":""}"><b>Casa ${k.casa}</b>${esc(txt)}<br><small>oída ${hora(k.visto)}</small></div>`;}).join("");
    document.getElementById("ev").innerHTML=d.eventos.map(e=>`<tr class="${e.nivel}"><td>${hora(e.ts)}</td><td>${esc(e.texto)}</td></tr>`).join("")||'<tr><td></td><td>Sin eventos todavía.</td></tr>';
  }catch(err){document.getElementById("casas").textContent="No puedo leer la alarma: "+err;}
}
pintar();setInterval(pintar,3000);
</script>"""

JS_LECCION = r"""<script>
const k="hecho:"+document.body.dataset.leccion, b=document.getElementById("hecho");
function lee(){try{return localStorage.getItem(k)==="1"}catch(e){return false}}
function pinta(){b.textContent=lee()?"✓ Hecha (desmarcar)":"Marcar como hecha";b.className=lee()?"sec":"";}
b.onclick=()=>{try{lee()?localStorage.removeItem(k):localStorage.setItem(k,"1")}catch(e){} pinta();};
pinta();
</script>"""

JS_LISTA = r"""<script>
document.querySelectorAll("[data-leccion]").forEach(a=>{try{if(localStorage.getItem("hecho:"+a.dataset.leccion)==="1")a.querySelector(".ok").textContent="✓"}catch(e){}});
</script>"""

JS_IA = r"""<script>
const hist=[]; const chat=document.getElementById("chat"), f=document.getElementById("f"), t=document.getElementById("t"), b=document.getElementById("enviar");
function burbuja(cls,txt){const d=document.createElement("div");d.className="msg "+cls;d.textContent=txt;chat.appendChild(d);d.scrollIntoView({block:"end"});return d;}
t.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();f.requestSubmit();}});
f.onsubmit=async e=>{
  e.preventDefault(); const q=t.value.trim(); if(!q) return;
  t.value=""; burbuja("yo",q); hist.push({role:"user",content:q});
  const d=burbuja("ia","Pensando…"); b.disabled=true; let txt="";
  try{
    const r=await fetch("/api/ia",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mensajes:hist.slice(-8)})});
    if(!r.ok){d.textContent=await r.text();b.disabled=false;return;}
    const rd=r.body.getReader(); const dec=new TextDecoder(); let resto="";
    while(true){const {value,done}=await rd.read(); if(done)break; resto+=dec.decode(value,{stream:true});
      const lineas=resto.split("\n"); resto=lineas.pop();
      for(const l of lineas){ if(!l.startsWith("data: ")||l.includes("[DONE]"))continue;
        try{const j=JSON.parse(l.slice(6)); const c=j.choices&&j.choices[0].delta&&j.choices[0].delta.content; if(c){txt+=c; d.textContent=txt; d.scrollIntoView({block:"end"});}}catch(_){} } }
    hist.push({role:"assistant",content:txt});
  }catch(err){d.textContent="No he podido hablar con la IA: "+err;}
  b.disabled=false; t.focus();
};
</script>"""


class Portal(BaseHTTPRequestHandler):
    server_version = "CentralCasa/1.0"

    def log_message(self, fmt, *args):  # sin ruido en el diario
        pass

    def enviar(self, codigo, cuerpo, tipo="text/html; charset=utf-8"):
        datos = cuerpo.encode("utf-8") if isinstance(cuerpo, str) else cuerpo
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(datos)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(datos)

    def no_encontrado(self, texto="No existe esa página."):
        self.enviar(404, pagina("No encontrado", f"<h1>No encontrado</h1><p class='sub'>{html.escape(texto)}</p><p><a href='/'>Volver al inicio</a></p>"))

    # --------------- GET ---------------
    def do_GET(self):
        ruta = unquote(urlparse(self.path).path)
        if ruta == "/":
            return self.inicio()
        if ruta == "/profesor":
            return self.redirigir("/profesor/")
        if ruta.startswith("/profesor/"):
            return self.profesor(ruta[len("/profesor/"):])
        if ruta == "/cursos":
            return self.lista_cursos()
        m = re.fullmatch(r"/cursos/([\w-]+)", ruta)
        if m:
            return self.un_curso(m.group(1))
        m = re.fullmatch(r"/cursos/([\w-]+)/([\w-]+)", ruta)
        if m:
            return self.leccion(m.group(1), m.group(2))
        m = re.fullmatch(r"/cursos/([\w-]+)/img/([\w.-]+)", ruta)
        if m:
            return self.estatico(os.path.join(DATOS, "cursos", m.group(1), "img"), m.group(2))
        if ruta == "/biblioteca":
            return self.saltar("biblioteca", "Biblioteca", "Wikipedia, Vikidia (enciclopedia para niños), libros y diccionario, sin internet.")
        if ruta == "/khan":
            return self.saltar("khan", "Khan Academy", "Vídeos y ejercicios de matemáticas y ciencias en español (Kolibri).")
        if ruta == "/ia":
            return self.pagina_ia()
        if ruta == "/alarma":
            return self.pagina_alarma()
        if ruta == "/api/alarma":
            return self.enviar(200, json.dumps(datos_alarma()), "application/json")
        if ruta == "/api/estado":
            return self.enviar(200, json.dumps({k: puerto_abierto(p) for k, p in PUERTOS.items()}), "application/json")
        return self.no_encontrado()

    def redirigir(self, a):
        self.send_response(302)
        self.send_header("Location", a)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def inicio(self):
        est = {k: puerto_abierto(p) for k, p in PUERTOS.items()}
        prof = os.path.isfile(os.path.join(DATOS, "profesor", "index.html"))
        ncur = len(cursos())

        def e(ok, si="Listo", no="No instalado"):
            return f'<span class="estado {"on" if ok else "off"}">{si if ok else no}</span>'

        alarma = alarma_reciente()
        aviso = f'<div class="aviso">⚠ {html.escape(alarma)} — <a href="/alarma">ver la alarma</a></div>' if alarma else ""
        cuerpo = f"""{aviso}
<div><h1>¿Qué vamos a hacer hoy?</h1>
<p class="sub">Todo funciona sin internet. Si algo pone «No instalado», pide ayuda a quien cuida la central.</p></div>
<div class="rejilla">
<a class="tile" href="/profesor/"><b>Profesor</b><span>Ejercicios con pistas paso a paso.</span>{e(prof, "Listo", "Falta copiar el profesor")}</a>
<a class="tile" href="/cursos"><b>Cursos</b><span>Ordenador, Linux, ciberseguridad y programación.</span>{e(ncur > 0, f"{ncur} cursos", "Sin cursos")}</a>
<a class="tile" href="/biblioteca"><b>Biblioteca</b><span>Wikipedia, Vikidia, libros y diccionario.</span>{e(est["biblioteca"])}</a>
<a class="tile" href="/khan"><b>Khan Academy</b><span>Vídeos y ejercicios de mates y ciencias.</span>{e(est["khan"])}</a>
<a class="tile" href="/ia"><b>Preguntar</b><span>Una IA que explica con paciencia. Puede equivocarse.</span>{e(est["ia"], "Lista", "Apagada")}</a>
<a class="tile" href="/alarma"><b>Alarma del barrio</b><span>Estado de las casas y lo que ha pasado.</span>{e(os.path.exists(os.path.join(DATOS, "alarma.db")), "Conectada", "Sin datos")}</a>
</div>"""
        self.enviar(200, pagina("Inicio", cuerpo))

    def profesor(self, resto):
        base = os.path.join(DATOS, "profesor")
        if resto in ("", "index.html") and not os.path.isfile(os.path.join(base, "index.html")):
            return self.enviar(200, pagina("Profesor", f"""<h1>Falta el profesor</h1>
<div class="nota">Copia el archivo HTML del profesor con:<br>
<code>sudo /opt/central/instalar.sh profesor /ruta/al/profesor.html</code><br>
Quedará en <code>{html.escape(base)}/index.html</code>.</div>"""))
        return self.estatico(base, resto or "index.html")

    def estatico(self, base, rel):
        destino = dentro(base, rel)
        if not destino or not os.path.isfile(destino):
            return self.no_encontrado()
        tipo = mimetypes.guess_type(destino)[0] or "application/octet-stream"
        if tipo.startswith("text/") or tipo in ("application/javascript", "application/json"):
            tipo += "; charset=utf-8"
        with open(destino, "rb") as f:
            self.enviar(200, f.read(), tipo)

    def lista_cursos(self):
        cs = cursos()
        if not cs:
            return self.enviar(200, pagina("Cursos", "<h1>Cursos</h1><p class='sub'>Todavía no hay cursos instalados.</p>"))
        items = "".join(
            f'<a class="tile" href="/cursos/{html.escape(c["slug"])}"><b>{html.escape(c.get("titulo", c["slug"]))}</b>'
            f'<span>{html.escape(c.get("descripcion", ""))}</span>'
            f'<span class="estado on">{len(c["lecciones"])} lecciones · {html.escape(c.get("para", ""))}</span></a>'
            for c in cs)
        self.enviar(200, pagina("Cursos", f"<h1>Cursos</h1><div class='rejilla'>{items}</div>"))

    def un_curso(self, slug):
        c = next((c for c in cursos() if c["slug"] == slug), None)
        if not c:
            return self.no_encontrado("Ese curso no está instalado.")
        filas = "".join(
            f'<a href="/cursos/{slug}/{html.escape(l["slug"])}" data-leccion="{slug}/{html.escape(l["slug"])}">'
            f'<span class="n">{i + 1:02d}</span>{html.escape(l["titulo"])}<span class="ok"></span></a>'
            for i, l in enumerate(c["lecciones"]))
        cuerpo = f"""<div><h1>{html.escape(c.get("titulo", slug))}</h1><p class="sub">{html.escape(c.get("descripcion", ""))}</p></div>
<div class="lista">{filas or '<a>Sin lecciones todavía.</a>'}</div>"""
        self.enviar(200, pagina(c.get("titulo", slug), cuerpo, JS_LISTA))

    def leccion(self, curso, slug):
        ls = lecciones(curso)
        idx = next((i for i, l in enumerate(ls) if l["slug"] == slug), None)
        if idx is None:
            return self.no_encontrado("Esa lección no existe.")
        ruta = os.path.join(DATOS, "cursos", curso, ls[idx]["archivo"])
        with open(ruta, encoding="utf-8") as f:
            cuerpo_md = md_a_html(f.read())
        ant = f'<a class="boton sec" href="/cursos/{curso}/{ls[idx - 1]["slug"]}">← Anterior</a>' if idx > 0 else f'<a class="boton sec" href="/cursos/{curso}">← Índice</a>'
        sig = f'<a class="boton" href="/cursos/{curso}/{ls[idx + 1]["slug"]}">Siguiente →</a>' if idx + 1 < len(ls) else f'<a class="boton" href="/cursos/{curso}">Fin del curso ✓</a>'
        cuerpo = f"""<div class="leccion">{cuerpo_md}</div>
<div class="nav">{ant}<button id="hecho" type="button">Marcar como hecha</button>{sig}</div>"""
        doc = pagina(ls[idx]["titulo"], cuerpo, JS_LECCION)
        doc = doc.replace("<body>", f'<body data-leccion="{curso}/{html.escape(slug)}">', 1)
        self.enviar(200, doc)

    def saltar(self, clave, titulo, texto):
        p = PUERTOS[clave]
        if puerto_abierto(p):
            return self.redirigir(f"http://localhost:{p}/")
        self.enviar(200, pagina(titulo, f"""<h1>{titulo}</h1><p class="sub">{texto}</p>
<div class="nota">Ahora mismo no está en marcha. Si se instaló, se arranca con
<code>sudo systemctl start central-{clave}</code>. Si no, hay que instalarlo con internet
(<code>sudo /opt/central/instalar.sh {clave}</code>).</div>"""))

    def pagina_ia(self):
        if not puerto_abierto(PUERTOS["ia"]):
            return self.saltar("ia", "Preguntar", "Una IA que funciona dentro de la central, sin internet.")
        cuerpo = """<div><h1>Preguntar</h1><p class="sub">Escribe tu duda y pulsa Enter. La IA vive en este ordenador:
no necesita internet, pero <strong>puede equivocarse</strong>. Si es importante, compruébalo en la Biblioteca.</p></div>
<div class="chat" id="chat"></div>
<form class="preg" id="f"><label for="t" hidden>Tu pregunta</label><textarea id="t" placeholder="Por ejemplo: ¿qué es una fracción? / ¿para qué sirve el comando ls?"></textarea>
<button id="enviar" type="submit">Preguntar</button></form>"""
        self.enviar(200, pagina("Preguntar", cuerpo, JS_IA))

    def pagina_alarma(self):
        cuerpo = """<div><h1>Alarma del barrio</h1><p class="sub">Lo que se oye por el cable de las alarmas. Se actualiza solo cada 3 segundos.</p></div>
<div class="casas" id="casas">Cargando…</div>
<h2>Últimos eventos</h2><div class="eventos"><table><tbody id="ev"></tbody></table></div>"""
        self.enviar(200, pagina("Alarma", cuerpo, JS_ALARMA))

    # --------------- POST ---------------
    def do_POST(self):
        if urlparse(self.path).path != "/api/ia":
            return self.no_encontrado()
        try:
            largo = int(self.headers.get("Content-Length", "0"))
            if largo > 200_000:
                return self.enviar(413, "Pregunta demasiado larga.", "text/plain; charset=utf-8")
            pet = json.loads(self.rfile.read(largo) or b"{}")
            mensajes = [m for m in pet.get("mensajes", [])
                        if isinstance(m, dict) and m.get("role") in ("user", "assistant") and isinstance(m.get("content"), str)][-8:]
        except (ValueError, TypeError):
            return self.enviar(400, "Petición no válida.", "text/plain; charset=utf-8")
        if not mensajes:
            return self.enviar(400, "No hay pregunta.", "text/plain; charset=utf-8")
        cuerpo = json.dumps({
            "messages": [{"role": "system", "content": SISTEMA_IA}] + mensajes,
            "stream": True, "temperature": 0.6, "max_tokens": 800,
        }).encode()
        req = urllib.request.Request(IA + "/v1/chat/completions", data=cuerpo,
                                     headers={"Content-Type": "application/json"})
        try:
            resp = urllib.request.urlopen(req, timeout=300)
        except (urllib.error.URLError, OSError) as e:
            return self.enviar(502, f"La IA no responde ({e}). ¿Está encendida? sudo systemctl start central-ia",
                               "text/plain; charset=utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            with resp:
                for linea in resp:
                    self.wfile.write(linea)
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass  # el usuario cerró la página


def main():
    srv = ThreadingHTTPServer(("127.0.0.1", PUERTO_WEB), Portal)
    print(f"Portal en http://localhost:{PUERTO_WEB} (datos en {DATOS})", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
