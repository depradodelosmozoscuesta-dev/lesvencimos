# La terminal: hablarle al ordenador con palabras

Hasta ahora has usado el ordenador con el ratón. La **terminal** es otra forma de usarlo: escribes una orden, pulsas Enter y el ordenador responde. Parece antigua, pero es la herramienta que usan los administradores de sistemas y los expertos en seguridad de todo el mundo.

## Ábrela

Menú → Sistema → **Terminal** (o pulsa `Ctrl` + `Alt` + `T`). Verás algo así:

```
estudiante@central:~$
```

Se lee así: *usuario* `estudiante`, en el ordenador `central`, en la carpeta `~` (tu carpeta personal). El `$` significa «escribe aquí».

## Tus tres primeras órdenes

| Orden | Qué hace |
|---|---|
| `whoami` | Dice con qué usuario estás. |
| `pwd` | Dice en qué carpeta estás (*print working directory*). |
| `ls` | Lista lo que hay en la carpeta. |

Escríbelas una a una:

```
whoami
pwd
ls
```

## Moverse: `cd`

`cd` significa *change directory*, cambiar de carpeta.

```
cd Documentos
pwd
cd ..
pwd
```

`..` quiere decir «la carpeta de arriba». `cd` a secas te devuelve siempre a casa.

## Ejercicio

1. Averigua en qué carpeta estás.
2. Entra en `Descargas` (si no existe, en cualquier carpeta que te muestre `ls`).
3. Vuelve a tu carpeta personal con una sola orden.

¿Te atascas? Pregúntale a **Preguntar**: «¿cómo vuelvo a mi carpeta personal en la terminal?». Te dará primero una pista.

## Lo que has aprendido

- La terminal recibe órdenes escritas.
- `whoami`, `pwd`, `ls` y `cd` te dicen quién eres, dónde estás, qué hay y cómo moverte.
- Equivocarse en la terminal no rompe nada con estas órdenes. Prueba sin miedo.
