# Bienvenida a la central

Este ordenador es la **central de la casa**. Funciona sin internet y con la batería de la alarma, así que puedes estudiar aunque se vaya la luz.

Desde la página de inicio llegas a todo:

| Botón | Para qué sirve |
|---|---|
| **Profesor** | Ejercicios con pistas. Si te atascas, te ayuda paso a paso. |
| **Cursos** | Lecciones ordenadas: ordenador, Linux, ciberseguridad, programación. |
| **Biblioteca** | Wikipedia, Vikidia (enciclopedia para niños), libros y diccionario. |
| **Khan Academy** | Vídeos y ejercicios de matemáticas y ciencias. |
| **Preguntar** | Una inteligencia artificial que explica con paciencia. |
| **Alarma del barrio** | Qué casas están armadas y si ha pasado algo. |

## Cómo seguir un curso

1. Entra en **Cursos** y elige uno.
2. Lee la lección con calma. Si hay comandos, **escríbelos tú**: no los copies y pegues. Así se aprende.
3. Al terminar pulsa **Marcar como hecha**. Verás una ✓ en el índice.
4. Pulsa **Siguiente**.

> Consejo: una lección al día aprovecha más que cinco de golpe.
