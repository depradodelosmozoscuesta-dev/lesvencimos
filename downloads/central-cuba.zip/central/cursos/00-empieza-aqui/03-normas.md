# Normas de la casa digital

1. **Tu contraseña es tuya.** No la digas, ni siquiera a amigos.
2. **La IA puede equivocarse.** Si algo es importante (salud, dinero, un examen), compruébalo en la Biblioteca o pregunta a una persona que sepa.
3. **La IA no da dosis de medicinas.** Eso lo decide un médico o un farmacéutico.
4. **Ciberseguridad se practica solo en casa.** Todo lo que aprendas de redes y seguridad pruébalo únicamente en esta central o en equipos tuyos. Entrar o escanear equipos o redes de otros es un delito.
5. **Si algo falla, no pasa nada.** Apunta qué estabas haciendo y avisa a quien cuida la central.
