# Cuentas y energía

## Dos cuentas

- **estudiante**: la de todos los días. Puede estudiar y practicar, pero no puede romper el sistema.
- **La cuenta de administrador**: solo para quien cuida la central. Sirve para instalar cosas y arreglar problemas.

Si cada persona usa su cuenta, cada una tiene su propio progreso en los cursos.

## La batería se comparte con la alarma

La central gasta bastante más que la alarma. Para que la alarma no se quede sin batería:

- **Apaga la central** cuando termines: menú → Apagar. No la desenchufes a lo bruto, porque se pueden estropear los archivos.
- Cuando haya corriente o sol, aprovecha para usarla más.
- La alarma sigue funcionando aunque la central esté apagada. Son aparatos distintos.
