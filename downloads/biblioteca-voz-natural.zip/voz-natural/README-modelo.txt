Coloca aquí un modelo Piper español compatible, por ejemplo:
  es_ES-…-medium.onnx
  es_ES-…-medium.onnx.json

Fuentes típicas (revisa licencia antes de redistribuir):
  https://github.com/rhasspy/piper
  https://huggingface.co/rhasspy/piper-voices

Cuando el modelo esté presente, biblioteca.html podrá
usar LVNaturalVoice.speak() para párrafos cortos.
