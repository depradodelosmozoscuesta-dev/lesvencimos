Coloca aquí el modelo Piper español (.onnx + .json) si lo usas.
Sin él, Biblioteca sigue leyendo con speechSynthesis del sistema.
No bloquea ni sustituye la voz del aparato.
