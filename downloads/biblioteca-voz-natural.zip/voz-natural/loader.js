/* Les vencimos · voz natural stub
 * Future: load Piper ONNX Spanish voice via onnxruntime-web.
 * API expected by biblioteca.html (when wired):
 *   window.LVNaturalVoice = { ready:false, speak(text, opts), stop() }
 */
(function (w) {
  w.LVNaturalVoice = {
    ready: false,
    version: 'stub-0',
    speak: function () {
      console.info('[LVNaturalVoice] Stub: descarga el modelo Piper para activar.');
      return Promise.reject(new Error('natural-voice-stub'));
    },
    stop: function () {}
  };
})(window);
