# 1º ESO Matemáticas — pack offline

No hay que instalar nada. Descomprime y abre index.html

**Qué es:** lecciones de **Educación obligatoria** (currículo oficial Castilla y León, Decreto 39/2022).
Este pack trae las lecciones **01–27** en HTML plano (shell + interactivos Mate). El resto irá entrando como *próximamente*.

**Cómo abrir (3 pasos)**

1. Descomprime este ZIP donde quieras.
2. Entra en la carpeta `1eso-matematicas-offline` (o la raíz del ZIP si ya están los archivos ahí).
3. Abre **`index.html`** con el navegador (doble clic o arrastrar).

Todo funciona **offline**, sin nube ni servidor (`file://`). Sin instalación, sin app store, sin «setup».

**Android:** descomprime con **Archivos / Mis archivos** y abre `index.html` desde ahí (`file://`).
Abrir desde la lista «Descargas» del navegador a veces usa `content://` y falla peor.

**Contenido:** `leccion-01.html` … `leccion-27.html`, widgets `lNN-….html`, calculadora, CSS/JS del shell y figuras SVG — todo en la misma carpeta.
