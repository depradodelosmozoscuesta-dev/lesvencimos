# 1º ESO Matemáticas — pack offline

No hay que instalar nada. Descomprime y abre index.html

**Qué es:** lecciones de **Educación obligatoria** (currículo oficial Castilla y León, Decreto 39/2022).
Este pack trae las lecciones **01–47** en HTML plano (shell + interactivos Mate).

**Cómo abrir (3 pasos)**

1. Descomprime este ZIP donde quieras.
2. Entra en la carpeta `1eso-matematicas-offline` (o la raíz del ZIP si ya están los archivos ahí).
3. Abre **`index.html`** con el navegador (doble clic o arrastrar).

Todo funciona **offline**, sin nube ni servidor (`file://`). Sin instalación, sin app store, sin «setup».

**Android:** descomprime con **Archivos / Mis archivos** y abre **`index.html` desde la carpeta descomprimida** (`file://`).
En Chrome/Android: menú → **Añadir a pantalla de inicio**.
No abras una lección individual desde Android **Descargas** mediante `content://`: así pueden fallar imágenes e iframes (abre siempre el hub `index.html`).

**Contenido:** `leccion-NN-titulo.html` (con slugs reales), alias `leccion-NN.html`, widgets `lNN-….html`, calculadora, CSS/JS, figuras SVG e iconos — todo en la misma carpeta.
