# 1º ESO Matemáticas — pack offline

**Qué es:** lecciones de **Educación obligatoria** (currículo oficial Castilla y León, Decreto 39/2022). Ahora mismo va **Lección 01** (presentación + widgets Mate). No es el pack **Profesor** (ese es otro ZIP, muchas materias).

**Cómo abrir**

1. Descomprime este ZIP donde quieras.
2. Abre en el navegador:
   - `profesor/1eso-matematicas/lecciones/01-presentacion.html` (L01), o
   - `profesor/1eso-matematicas/1eso-matematicas.html` (índice del curso), o
   - `index.html` en la raíz (atajo).

Todo funciona **offline**, sin nube ni servidor (`file://`).

**Android:** descomprime con **Archivos / Mis archivos** y abre el HTML desde ahí (`file://`). Abrir desde la lista «Descargas» del navegador a veces usa `content://` y falla peor; Archivos es lo más fiable.

Más lecciones irán entrando en actualizaciones de este pack.
