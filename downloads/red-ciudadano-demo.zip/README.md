# Demo escaparate — Red Ciudadano Valladolid

Paquete de **capturas** + pitch + documentación cívica para lesvencimos.com `/red`.

## Contenido

- `PITCH.md` — mensaje comercial (solo red cívica; sin juego)
- `capturas/` — PNGs de home, mapa, calles, casa, prensa, mensajes, etc.
- `docs/` — ARRANQUE, RECORRIDO-10MIN (usar Parte A cívica), PUCELA, taller, paradigma

## Demo en vivo

Repo privado del nodo:

```bash
make run-civic
```

→ `http://127.0.0.1:8080/`

La cáscara PWA estática (sin API) está en `red-ciudadano-pwa-static.zip` del escaparate.
