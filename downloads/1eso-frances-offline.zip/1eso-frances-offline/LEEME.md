# 1º ESO Francés — pack offline

No hay que instalar nada. Descomprime y abre **ABRE-AQUI.html** (o index.html).

**Qué es:** pack de **Segunda Lengua Extranjera (Francés)** de 1º ESO (currículo de Castilla y León, Decreto 39/2022, LOMLOE). **No es Inglés.**
Este pack trae el **curso completo** (lecciones **01–40/40**) (Segunda Lengua Extranjera (Francés) 1º ESO: currículo de Castilla y León (Decreto 39/2022, LOMLOE); comunicación, plurilingüismo e interculturalidad; no es Inglés ni 1.ª lengua extranjera) en HTML plano (shell + modo maestro).
Revisor Dios **CONFIRMA** OK curso (0 críticos).

**Cómo abrir (Android / PC) — 4 pasos**

1. Descarga el ZIP.
2. Abre **Archivos / Mis archivos** (NO la lista Descargas del navegador).
3. Descomprime y entra en la carpeta `1eso-frances-offline`.
4. Toca **`ABRE-AQUI.html`** o **`index.html`** → Chrome / Samsung Internet.

Todo funciona **offline**, sin nube ni servidor (`file://`). Sin instalación, sin app store, sin «setup».

**Importante en Android:** abre siempre desde la **carpeta descomprimida** (`file://`).
**Nunca** abras el HTML desde la lista Descargas del navegador (`content://`): ahí fallan
imágenes, CSS e interactivos.

En Chrome/Android: menú → **Añadir a pantalla de inicio**.

**Identidad:** material educativo de **Segunda Lengua Extranjera (Francés)**. Se basa en Decreto 39/2022 (LOMLOE). **No es Inglés.** No sustituye al criterio del centro ni del profesorado.

**Contenido:** `ABRE-AQUI.html`, `index.html`, `LEEME.md`, `leccion-01.html`…`leccion-40.html`,
`maestro-NN.json`, carpeta `_maestro/`, calculadora, CSS/JS e iconos — todo en la misma carpeta.
