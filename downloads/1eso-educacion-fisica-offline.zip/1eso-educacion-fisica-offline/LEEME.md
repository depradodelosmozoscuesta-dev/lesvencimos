# 1º ESO Educación Física — pack offline

No hay que instalar nada. Descomprime y abre **ABRE-AQUI.html** (o index.html).

**Qué es:** lecciones de **Educación obligatoria** (currículo oficial Castilla y León, Decreto 39/2022 · Educación Física).
Este pack trae el **curso completo** (lecciones **01–32/32**) (temario completo EF 1º CyL (vida activa, organización, motricidad, emociones, cultura motriz, entorno)) en HTML plano (shell + modo maestro).
Revisor Dios **CONFIRMA** OK curso (0 críticos).

**Cómo abrir (Android / PC) — 4 pasos**

1. Descarga el ZIP.
2. Abre **Archivos / Mis archivos** (NO la lista Descargas del navegador).
3. Descomprime y entra en la carpeta `1eso-educacion-fisica-offline`.
4. Toca **`ABRE-AQUI.html`** o **`index.html`** → Chrome / Samsung Internet.

Todo funciona **offline**, sin nube ni servidor (`file://`). Sin instalación, sin app store, sin «setup».

**Importante en Android:** abre siempre desde la **carpeta descomprimida** (`file://`).
**Nunca** abras el HTML desde la lista Descargas del navegador (`content://`): ahí fallan
imágenes, CSS e interactivos.

En Chrome/Android: menú → **Añadir a pantalla de inicio**.

**Salud y seguridad:** este material es **educativo**. **No** es consejo médico ni sustituye al profesorado de Educación Física o a un profesional sanitario. Prácticas pensadas para casa, patio o parque. Ante dolor, mareo o lesión: **parar** y consultar. En una emergencia: llama al **112**. La lección de primeros auxilios (L14) explica el marco PAS/SVB/112; **no** es un tutorial de RCP.

**Contenido:** `ABRE-AQUI.html`, `index.html`, `LEEME.md`, `leccion-01`…`leccion-32-….html`,
alias `leccion-NN.html`, `maestro-NN.json`, carpeta `_maestro/`, calculadora, CSS/JS e iconos — todo en la misma carpeta.
